//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ADdemo.rc
//
#define IDI_MAIN_ICON                   102
#define IDC_ADCURSOR                    104
#define IDD_DIALOG1                     106
#define IDC_RADIO1                      1006
#define IDC_RADIO2                      1007
#define IDC_EDIT1                       1009
#define IDC_LIST2                       1011
#define IDC_BUTTON1                     1023
#define IDC_PROGRESS1                   1026
#define IDC_EDIT2                       1027
#define IDC_COMBO1                      1028
#define IDC_COMBO2                      1029
#define IDC_LIST1                       1030
#define ID_NOSOUND                      1031
#define IDC_EDIT3                       1032
#define IDC_STATIC2                     1033
#define IDC_BUTTON2                     1034
#define IDC_STATIC3                     1035
#define IDC_CHECK1                      1036
#define IDC_SLIDER1                     1038
#define MOTIONBLUR_RADIO                1040
#define RADIALBLUR_RADIO                1041
#define NOBLUR_RADIO                    1042
#define FULLSCREEN_CHECK                1045

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1046
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

// A3Dfile.cpp: implementation of the A3Dfile class.
//
//////////////////////////////////////////////////////////////////////
#define MAXA3DFILESIZE 1024*1024*2 // max 2 Mb

#include <stdio.h>
#include <io.h>
#include <string.h>
#include "A3Dfile.h"


void write_string0 (FILE *f, char *st)
{
  int k;

  for (k=0; st[k]!='\0'; k++)
    fwrite(&st[k], sizeof(char), 1, f);
  fwrite(&st[k], sizeof(char), 1, f);  // scrivo anche il \0
}


void write_chunk_header(FILE *f, int id, char *no, int s)
{
  fwrite(&id, sizeof(int), 1, f);
  write_string0(f, no);
  fwrite(&s, sizeof(int), 1, f);
}
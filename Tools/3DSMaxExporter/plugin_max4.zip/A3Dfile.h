// A3Dfile.h: interface for the A3Dfile class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _A3DFILE_H_
#define _A3DFILE_H_


// costanti definite per i tipi di chunk "statici"
#define SCENE_GENERAL_INFO_ID  0
#define SCENE_MATERIAL_LIST_ID  50
#define TRI_MESH_ID  1
#define TRI_MESH_VERTEX_LIST_ID 2
#define TRI_MESH_FACES_LIST_ID  3
#define TRI_MESH_TEXTURE_VERTEX_LIST_ID 4
#define TRI_MESH_TEXTURE_FACES_LIST_ID 5
#define HELPER_OBJECT_ID  6
#define BONE_OBJECT_ID  80
#define IKCHAIN_OBJECT_ID  81
#define PATCH_MESH_ID  7
#define CAMERA_ID  8
#define OMNI_LIGHT_ID  9
#define SPRAY_PARTICLE_SYSTEM_ID 10
#define WIND_MODIFIER_ID  60
#define GRAVITY_MODIFIER_ID  61
#define PHYSIC_MODIFIER_ID   62
#define TWIST_MODIFIER_ID   63
#define RIPPLE_MODIFIER_ID   64
#define BEND_MODIFIER_ID   65
#define TAPER_MODIFIER_ID   66
#define MELT_MODIFIER_ID   67
#define NOISE_MODIFIER_ID   68
#define STRETCH_MODIFIER_ID   69
#define FFD_MODIFIER_ID       70
#define SKIN_MODIFIER_ID      71

// costanti definite per i tipi di chunk "dinamici" (keyframer)
#define POSITION_TRACK_ID  11
#define ROTATION_TRACK_ID  12
#define SCALE_TRACK_ID  20
#define CAMERA_FOV_TRACK_ID  13
#define CAMERA_ROLL_TRACK_ID  14
#define COLOR_TRACK_ID  15
#define LIGHT_POSITION_TRACK_ID  16
#define CAMERA_POSITION_TRACK_ID  17
#define CAMERA_TARGET_TRACK_ID  18
#define PATCH_VERTEX_TRACK_ID  19
#define PATCH_VECTOR_TRACK_ID  21
#define MATERIAL_OPACITY_TRACK_ID  22

#define OSM_CENTER_TRACK_ID      23
#define TWIST_ANGLE_TRACK_ID     24
#define TWIST_BIAS_TRACK_ID      25
#define TWIST_UPLIMIT_TRACK_ID   26
#define TWIST_LOWLIMIT_TRACK_ID  27

#define RIPPLE_AMP1_TRACK_ID      28
#define RIPPLE_AMP2_TRACK_ID      29
#define RIPPLE_WAVELEN_TRACK_ID   30
#define RIPPLE_PHASE_TRACK_ID     31
#define RIPPLE_DECAY_TRACK_ID     32

#define BEND_ANGLE_TRACK_ID     33
#define BEND_DIR_TRACK_ID       34
#define BEND_UPLIMIT_TRACK_ID   35
#define BEND_LOWLIMIT_TRACK_ID  36

#define MELT_AMOUNT_TRACK_ID     37
#define MELT_SPREAD_TRACK_ID     38

#define STRETCH_STRETCH_TRACK_ID   39
#define STRETCH_AMPLIFY_TRACK_ID   40
#define STRETCH_UPLIMIT_TRACK_ID   41
#define STRETCH_LOWLIMIT_TRACK_ID  42

#define TAPER_AMOUNT_TRACK_ID      43
#define TAPER_CURVE_TRACK_ID       44
#define TAPER_UPLIMIT_TRACK_ID     45
#define TAPER_LOWLIMIT_TRACK_ID    46

#define FFD_CONTROLPOINT_TRACK_ID  47
#define FFD_POSITION_TRACK_ID      48
#define FFD_ROTATION_TRACK_ID      49
#define FFD_SCALE_TRACK_ID         51  // il 50 � occupato

#define NOISE_STRENGTH_TRACK_ID    52
#define NOISE_FREQ_TRACK_ID        53
#define NOISE_PHASE_TRACK_ID       54
#define NOISE_SCALE_TRACK_ID       55

// chuck per il raytracing
#define RAY_SPHERE_ID 500
#define RAY_BOX_ID 501
#define RAY_PLANE_ID 502
#define RAY_CYLINDER_ID 503
#define RAY_CONE_ID 504
#define RAY_TORUS_ID 505


// indica il fine scena (cmq controllare il suo flag di dato)
#define END_SCENE_ID 100


// costanti definite per il tipo di controller
#define LINEAR_CONTROLLER   0
#define BEZIER_CONTROLLER   1
#define TCB_CONTROLLER      2


// per gli oggetti helper definisco i seguenti tipi
#define DUMMY_HELPER 0
#define BONE_HELPER  1



void write_chunk_header(FILE *f, int id, char *no, int s);
void write_string0 (FILE *f, char *st);

#endif 
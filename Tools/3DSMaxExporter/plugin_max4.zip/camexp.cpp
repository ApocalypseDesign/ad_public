
#include "SceneExport.h"
#include "A3Dfile.h"

void SkeletonExporter::export_camera(INode *node)
{
  Control *c;
  int size_key;
  float camera_znear, camera_zfar;

  fprintf(fTXT, "Camera found\n");
  write_chunk_header(fA3D, CAMERA_ID, node->GetName(), 40);
  write_chunk_header(fRAY, CAMERA_ID, node->GetName(), 40);

  INode* target = node->GetTarget();
  if (target) fprintf(fTXT, "Type : target\n");
  else fprintf(fTXT, "Type : free\n");
  fprintf(fTXT, "Name : %s\n", node->GetName());

  TimeValue t = 0;
  CameraState cs;
  Interval valid = FOREVER;
  ObjectState os = node->EvalWorldState(t);
  CameraObject *cam = (CameraObject *)os.obj;
  GenCamera *gencam = (GenCamera *)os.obj;
  cam->EvalCameraState(t, valid, &cs);

  // salviamo znear e zfar
  camera_znear=2;
  camera_zfar=1000;
  if (cs.manualClip)
  {
	camera_znear=cs.hither;
	camera_zfar=cs.yon;
  }
  fprintf(fTXT, "Znear = %f \n", camera_znear);
  fwrite(&camera_znear, sizeof(float), 1, fA3D);
  fwrite(&camera_znear, sizeof(float), 1, fRAY);
  fprintf(fTXT, "Zfar = %f \n", camera_zfar);
  fwrite(&camera_zfar, sizeof(float), 1, fA3D);
  fwrite(&camera_zfar, sizeof(float), 1, fRAY);


  // salviamo l'angolo di FOV
  fprintf(fTXT, "FOV (rad) = %f \n", cs.fov);
  fwrite(&cs.fov, sizeof(float), 1, fA3D);
  fwrite(&cs.fov, sizeof(float), 1, fRAY);

  // salviamo l'angolo di roll
  float roll0;
  c=node->GetTMController()->GetRollController();
  c->GetValue(0, &roll0, valid);	
  fprintf(fTXT, "Roll (rad) = %f \n", roll0);
  fwrite(&roll0, sizeof(float), 1, fA3D);
  fwrite(&roll0, sizeof(float), 1, fRAY);

  // salviamo la posizione nel mondo
  Matrix3 pivot = node->GetNodeTM(t);
  Point3 row = pivot.GetRow(3);
  fprintf(fTXT, "Camera world position : x=%f, y=%f, z=%f\n", row.x, row.y, row.z);
  fwrite(&row.x, sizeof(float), 1, fA3D);
  fwrite(&row.y, sizeof(float), 1, fA3D);
  fwrite(&row.z, sizeof(float), 1, fA3D);
  fwrite(&row.x, sizeof(float), 1, fRAY);
  fwrite(&row.y, sizeof(float), 1, fRAY);
  fwrite(&row.z, sizeof(float), 1, fRAY);

  // salviamo la posizione del target nel mondo
  if (target)
  {
    pivot = node->GetTarget()->GetNodeTM(t);
    row = pivot.GetRow(3);
    fprintf(fTXT, "Target world position : x=%f, y=%f, z=%f\n", row.x, row.y, row.z);
    fwrite(&row.x, sizeof(float), 1, fA3D);
    fwrite(&row.y, sizeof(float), 1, fA3D);
    fwrite(&row.z, sizeof(float), 1, fA3D);
    fwrite(&row.x, sizeof(float), 1, fRAY);
    fwrite(&row.y, sizeof(float), 1, fRAY);
    fwrite(&row.z, sizeof(float), 1, fRAY);
  }

  
  // esportiamo l'animazione della posizione della camera
  // se ci sono un numero di key > 0
  c=node->GetTMController()->GetPositionController();
  if ((c) && (c->NumKeys()>0))
  {
	 if (IsTCBControl(c)) size_key=36;
	 else
	 if (IsBezierControl(c)) size_key=40;
	 else size_key=16;
	 fprintf(fTXT, "Camera position track present.");
     write_chunk_header(fA3D, CAMERA_POSITION_TRACK_ID,
	                    node->GetName(), 1+4+c->NumKeys()*size_key);
     export_Point3_track(c, fA3D);
     write_chunk_header(fRAY, CAMERA_POSITION_TRACK_ID,
	                    node->GetName(), 1+4+c->NumKeys()*size_key);
     export_Point3_track(c, fRAY);
  }

  // esportiamo l'animazione della posizione del target
  if (target)
  {
    c=target->GetTMController()->GetPositionController();
    if ((c) && (c->NumKeys()>0))
	{
	  if (IsTCBControl(c)) size_key=36;
	  else
	  if (IsBezierControl(c)) size_key=40;
	  else size_key=16;
	  fprintf(fTXT, "Target position track present.");
	  write_chunk_header(fA3D, CAMERA_TARGET_TRACK_ID,
		                 node->GetName(), 1+4+c->NumKeys()*size_key);
	  export_Point3_track(c, fA3D);

	  write_chunk_header(fRAY, CAMERA_TARGET_TRACK_ID,
		                 node->GetName(), 1+4+c->NumKeys()*size_key);
	  export_Point3_track(c, fRAY);
	}
  }

  
  // esportiamo le tracce di FOV
  c=gencam->GetFOVControl();
  if ((c) && (c->NumKeys()>0))
  {
	 if (IsTCBControl(c)) size_key=28;
	 else
	 if (IsBezierControl(c)) size_key=16;
	 else size_key=8;
	 fprintf(fTXT, "Camera FOV track present.");
     write_chunk_header(fA3D, CAMERA_FOV_TRACK_ID,
	                    node->GetName(), 1+4+c->NumKeys()*size_key);
     export_float_track(c, (float)(180.0/3.14159265358979323846), fA3D);

     write_chunk_header(fRAY, CAMERA_FOV_TRACK_ID,
	                    node->GetName(), 1+4+c->NumKeys()*size_key);
     export_float_track(c, (float)(180.0/3.14159265358979323846), fRAY);
  }


  // esportiamo le tracce di roll  
  c=node->GetTMController()->GetRollController();
  if ((c) && (c->NumKeys()>0))
  {
	 if (IsTCBControl(c)) size_key=28;
	 else
	 if (IsBezierControl(c)) size_key=16;
	 else size_key=8;
	 fprintf(fTXT, "Camera roll track present.");
     write_chunk_header(fA3D, CAMERA_ROLL_TRACK_ID,
	                    node->GetName(), 1+4+c->NumKeys()*size_key);
     export_float_track(c, (float)(180.0/3.14159265358979323846), fA3D);

     write_chunk_header(fRAY, CAMERA_ROLL_TRACK_ID,
	                    node->GetName(), 1+4+c->NumKeys()*size_key);
     export_float_track(c, (float)(180.0/3.14159265358979323846), fRAY);
  }

  fprintf(fTXT, "\n\n");
}
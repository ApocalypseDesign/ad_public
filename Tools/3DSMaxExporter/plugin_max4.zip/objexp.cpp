
#include "SceneExport.h"
#include "A3Dfile.h"
#include "Phyexp.h"
#include "OSM.h"
#include "iSkin.h"

Modifier* SkeletonExporter::FindPhysiqueModifier (INode* node)
{
  Object* ObjectPtr = node->GetObjectRef();
  if (!ObjectPtr) return NULL;

  while (ObjectPtr->SuperClassID() == GEN_DERIVOB_CLASS_ID && ObjectPtr)
  {
    IDerivedObject *DerivedObjectPtr = (IDerivedObject *)(ObjectPtr);
    int ModStackIndex = 0;
    while (ModStackIndex < DerivedObjectPtr->NumModifiers())
	{
       Modifier* ModifierPtr = DerivedObjectPtr->GetModifier(ModStackIndex);
       if (ModifierPtr->ClassID() == Class_ID(PHYSIQUE_CLASS_ID_A, PHYSIQUE_CLASS_ID_B))
         return ModifierPtr;
       ModStackIndex++;
	}
    ObjectPtr = DerivedObjectPtr->GetObjRef();
  }
  return NULL;
}


Modifier* SkeletonExporter::FindSkinModifier (INode *node)
{
  Object* ObjectPtr = node->GetObjectRef();
  if (!ObjectPtr) return NULL;

  while (ObjectPtr->SuperClassID() == GEN_DERIVOB_CLASS_ID && ObjectPtr)
  {
    IDerivedObject *DerivedObjectPtr = (IDerivedObject *)(ObjectPtr);
    int ModStackIndex = 0;
    while (ModStackIndex < DerivedObjectPtr->NumModifiers())
	{
       Modifier* ModifierPtr = DerivedObjectPtr->GetModifier(ModStackIndex);
       if (ModifierPtr->ClassID() == SKIN_CLASSID)
         return ModifierPtr;
       ModStackIndex++;
	}
    ObjectPtr = DerivedObjectPtr->GetObjRef();
  }
  return NULL;
}


void SkeletonExporter::GetPivotOffset(INode* node, Point3 *p)
{
 // get the pivot offset and remove the rotational/scale component
    Matrix3 mat(TRUE);
    Quat qRot = node->GetObjOffsetRot();
    qRot.MakeMatrix(mat);
 // max scales the object if the pivot is scaled so skip.
 // m.SetScale( ((SceneEntry *)data)->node->GetObjOffsetScale().s );
    Point3 pivot = -node->GetObjOffsetPos();
    mat = Inverse(mat);
    Point3 pOff = VectorTransform(mat, pivot);
    p->x=pOff.x;
    p->y=pOff.y;
    p->z=pOff.z;
}


BOOL SkeletonExporter::TMNegParity(Matrix3 &m)
{ return (DotProd(CrossProd(m.GetRow(0),m.GetRow(1)),m.GetRow(2))<0.0)?1:0; }


// Return a pointer to a TriObject given an INode or return NULL
// if the node cannot be converted to a TriObject
TriObject *SkeletonExporter::GetTriObjectFromNode(INode *node, int &deleteIt)
{
  deleteIt = FALSE;
  Object *obj = node->EvalWorldState(0).obj;
  if (obj->CanConvertToType(Class_ID(TRIOBJ_CLASS_ID, 0)))
  { 
    TriObject *tri = (TriObject *) obj->ConvertToType(0, Class_ID(TRIOBJ_CLASS_ID, 0));
	// Note that the TriObject should only be deleted
	// if the pointer to it is not equal to the object
	// pointer that called ConvertToType()
	if (obj != tri) deleteIt = TRUE;
	return tri;
  }
  else return NULL;
}


// Return a pointer to a TriObject given an Object or return NULL
// if the object cannot be converted to a TriObject
TriObject *SkeletonExporter::GetTriObjectFromObject(Object *obj, int &deleteIt)
{
  deleteIt = FALSE;

  if (!obj) return(NULL);
  if (obj->CanConvertToType(Class_ID(TRIOBJ_CLASS_ID, 0)))
  { 
    TriObject *tri = (TriObject *) obj->ConvertToType(0, Class_ID(TRIOBJ_CLASS_ID, 0));
	// Note that the TriObject should only be deleted
	// if the pointer to it is not equal to the object
	// pointer that called ConvertToType()
	if (obj != tri) deleteIt = TRUE;
	return tri;
  }
  else return NULL;
}


// Tool di ottimizzazione per le mesh: rimozione di vertici geometrici
// duplicati
void SkeletonExporter::build_valid_vertex (Mesh *mesh, Point3 *vv,
										   int *hash, int *num_vv)
{
   int i, j , k, nv;
   Point3 a;
   BOOL found;

   nv=mesh->getNumVerts();
   i=0;

   for (j=0; j<nv; j++)
   {
	  a=mesh->verts[j];
	  found=FALSE;
	  k=0;
	  while ((found==FALSE) && (k<i))
	  {
		 if ((a.x==vv[k].x) && (a.y==vv[k].y) && (a.z==vv[k].z))
		 found=TRUE;
		 else k++;
      }

	  // aggiungo il vertice, creo la sua entry nella tabella hash
	  if (found==FALSE)
	  {
		 vv[i]=a;
		 hash[j]=i;
		 i++;
	  }
	  else hash[j]=k;
   }

   *num_vv=i;
}


void SkeletonExporter::build_valid_texture_vertex (Mesh *mesh, UVVert *uv, int *hash, int *num_uv)
{
   int i, j , k, nv;
   UVVert a;
   BOOL found;

   nv=mesh->getNumTVerts();
   i=0;

   for (j=0; j<nv; j++)
   {
	  a=mesh->tVerts[j];
	  found=FALSE;
	  k=0;
	  while ((found==FALSE) && (k<i))
	  {
		 if ((a.x==uv[k].x) && (a.y==uv[k].y))
		 found=TRUE;
		 else k++;
      }

	  // aggiungo il vertice, creo la sua entry nella tabella hash
	  if (found==FALSE)
	  {
		 uv[i]=a;
		 hash[j]=i;
		 i++;
	  }
	  else hash[j]=k;
   }

   *num_uv=i;
}


// Tool di ottimizzazione per le mesh: rimozione di triangoli
// geometrici degeneri
void SkeletonExporter::build_valid_face (Mesh *mesh, int *vf,
										 int *num_vf)
{
   int nt, i, j;
   Point3 a, b, c, d1, d2, d3;

   nt=mesh->getNumFaces();
   i=0;
   for (j=0; j<nt; j++)
   {
	  a=mesh->verts[mesh->faces[j].v[0]];
	  b=mesh->verts[mesh->faces[j].v[1]];
	  c=mesh->verts[mesh->faces[j].v[2]];
	  d1=a-b;
	  d2=a-c;
	  d3=b-c;
	  if ((d1.x==0) && (d1.y==0) && (d1.z==0)) continue;
	  if ((d2.x==0) && (d2.y==0) && (d2.z==0)) continue;
	  if ((d3.x==0) && (d3.y==0) && (d3.z==0)) continue;
	  vf[i]=j;
	  i++;
   }
   *num_vf=i;
}


void SkeletonExporter::export_geometric_object(INode *node)
{
  int tf1, tf2, tf3, size_phys, type_phys, has_known_modifiers;
  int vx1, vx2, vx3;
  int numTEXvert=0, j, i, size_skin, k, nv, nt, sf, sm;
  Modifier *physmod=(Modifier *)NULL, *skinmod=(Modifier *)NULL;
  BOOL needDel, ndel, negScale;
  TriObject* tri, *triphys;
  UVVert tv;
  Mesh *mesh, *meshphys;
  Point3 v, row;
  long fpos;
  typedef char Bone_Name[40];
  Bone_Name bones_names[70];
  int num_bones_names;
  int assignedBone, numBones;
  short int numBones_short;
  // per le ottimizzazioni e rimozioni di roba degenre
  Point3 *valid_vertex;
  int *vertex_hash;
  UVVert *uv;
  int *hash_uv;
  int *valid_faces;


  ObjectState os = node->EvalWorldState(0);
  if (!os.obj) return;
	
  // Targets are actually geomobjects, but we will export them
  // from the camera and light objects, so we skip them here.
  if (os.obj->ClassID() == Class_ID(TARGET_CLASS_ID, 0))
  {
	fprintf(fTXT, "\n");
    return;
  }

  INode *padre=node->GetParentNode();
  Mtl *materiale=node->GetMtl();

  if ((padre) && (strcmp(padre->GetName(), "Scene Root")!=0))
  sf=strlen(padre->GetName())+1;
  else sf=0;
  if (materiale) sm=strlen(materiale->GetName())+1;
  else sm=0;
  
  // flag padre + nome padre + flag materiale + nome materiale +
  // + matrice di trasformazione per t=0 + world position +
  // + pivot
  write_chunk_header(fA3D, TRI_MESH_ID, node->GetName(),
	                 4+sf+4+sm+36+12+12);

  // scrivo il padre (flag, nome)
  fwrite(&sf, sizeof(int), 1, fA3D);
  if (sf>0) write_string0(fA3D, padre->GetName());

  // scrivo il materiale di base (flag, nome)
  fwrite(&sm, sizeof(int), 1, fA3D);
  if (sm>0) write_string0(fA3D, materiale->GetName());

  // stesse informazioni a livello testuale
  fprintf(fTXT, "Geometric object found\n");
  fprintf(fTXT, "Name : %s\n", node->GetName());
  if (padre) fprintf(fTXT, "Name parent : %s\n", node->GetParentNode()->GetName());
  if (materiale) fprintf(fTXT, "Material used : %s\n", node->GetMtl()->GetName());

  Matrix3 mat = node->GetNodeTM(0);
  Matrix3 mat_checkneg = node->GetNodeTM(0);
  
  // scrittura riga 0 della matrice locale (local coordinate system)
  row = mat.GetRow(0);
  fprintf(fTXT, "Local coord. system row0 : %f, %f, %f\n", row.x, row.y, row.z);
  fwrite(&row.x, sizeof(float), 1, fA3D);
  fwrite(&row.y, sizeof(float), 1, fA3D);
  fwrite(&row.z, sizeof(float), 1, fA3D);
  // scrittura riga 1 della matrice locale (local coordinate system)
  row = mat.GetRow(1);
  fprintf(fTXT, "Local coord. system row1 : %f, %f, %f\n", row.x, row.y, row.z);
  fwrite(&row.x, sizeof(float), 1, fA3D);
  fwrite(&row.y, sizeof(float), 1, fA3D);
  fwrite(&row.z, sizeof(float), 1, fA3D);
  // scrittura riga 2 della matrice locale (local coordinate system)
  row = mat.GetRow(2);
  fprintf(fTXT, "Local coord. system row2 : %f, %f, %f\n", row.x, row.y, row.z);
  fwrite(&row.x, sizeof(float), 1, fA3D);
  fwrite(&row.y, sizeof(float), 1, fA3D);
  fwrite(&row.z, sizeof(float), 1, fA3D);
  // scrittura posizione nel mondo (riga 3)
  row = mat.GetRow(3);
  fprintf(fTXT, "World position : x=%f, y=%f, z=%f\n", row.x, row.y, row.z);
  fwrite(&row.x, sizeof(float), 1, fA3D);
  fwrite(&row.y, sizeof(float), 1, fA3D);
  fwrite(&row.z, sizeof(float), 1, fA3D);
 
  // scrittura del punto di pivot
  GetPivotOffset(node, &row);
  fprintf(fTXT, "Pivot point : %f, %f, %f\n", row.x, row.y, row.z);
  fwrite(&row.x, sizeof(float), 1, fA3D);
  fwrite(&row.y, sizeof(float), 1, fA3D);
  fwrite(&row.z, sizeof(float), 1, fA3D);


  tri = GetTriObjectFromNode(node, needDel);
  if (!tri) return;
  mesh = &tri->GetMesh();

  // vale come segue:
  // 1 = non ha nessun modificatore
  // 2 = ha solo il physic
  // 3 = non ha il physic ma in cascata ha solo modificatori di
  //     tipo TWISTER (e quelli che supportero' nell'engine)
  // 4 = ha modificatori implementati ma anche non implementati
  // NB: se la mesh ha un physic modifier o tutti OSM implementati
  // devo esportare i vertici dell'oggetto base e non
  // dell'oggetto evaluato al tempo 0, perche' la deformazione
  // la applico a runtime nell'engine

  has_known_modifiers=KnownModifiers(node);
  if (has_known_modifiers==2)
  {
    physmod=FindPhysiqueModifier(node);
    if (physmod) fprintf(fTXT, "Physisc modifier found\n");
  }
  else
  if (has_known_modifiers==5)
  {
    skinmod=FindSkinModifier(node);
    if (skinmod) fprintf(fTXT, "Skin modifier found\n");
  }
  
  if (has_known_modifiers==3)
  {
    mat_checkneg = node->GetObjTMBeforeWSM(0);
	negScale=FALSE;
  }
  else negScale = TMNegParity(mat_checkneg);
  if (negScale) { vx1 = 2; vx2 = 1;	vx3 = 0; }
  else          { vx1 = 0; vx2 = 1; vx3 = 2; }

  nv=mesh->getNumVerts();
  numTEXvert = mesh->getNumTVerts();
  nt=mesh->getNumFaces();
  valid_vertex=new Point3[nv];
  vertex_hash=new int[nv];
  uv=new UVVert[numTEXvert];
  hash_uv=new int[numTEXvert];
  valid_faces=new int[nt];


  fprintf(fTXT, "Number of vertex (non optimized) : %d\n", nv);
  // NB: differenzio a seconda che c'e' / ci sono modificatori
  // implementati
  if ( // Physic                  Skin
	  (has_known_modifiers==2) || (has_known_modifiers==5) ||
	  // altri (ripple, bend, etc)
	  (has_known_modifiers==3))
  {
	  // scrivo i vertici dell'oggetto base (not modified)
      Object *obase=GetBaseObjectFromNode(node);
	  triphys = GetTriObjectFromObject(obase, ndel); if (!triphys) return;
      meshphys = &triphys->GetMesh();

	  build_valid_vertex(meshphys, valid_vertex, vertex_hash, &nv);
      fprintf(fTXT, "Number of vertex (optimized): %d\n", nv);
      write_chunk_header(fA3D, TRI_MESH_VERTEX_LIST_ID, node->GetName(),
	                     4+nv*12);
      fwrite(&nv, sizeof(int), 1, fA3D);
      for (int i=0; i<nv; i++)
	  {
         v = valid_vertex[i];
	     fprintf(fTXT, "Vertex %d : x=%f,  y=%f,  z=%f\n", i, v.x, v.y, v.z);
	     fwrite(&v.x, sizeof(float), 1, fA3D);
	     fwrite(&v.y, sizeof(float), 1, fA3D);
	     fwrite(&v.z, sizeof(float), 1, fA3D);
	 }
     if (ndel) delete triphys;
  }
  else
  {
	// scrivo i vertici dell'oggetto che ha seguito gia' la
	// pipe geometrica del MAX
	build_valid_vertex(mesh, valid_vertex, vertex_hash, &nv);
    fprintf(fTXT, "Number of vertex (optimized): %d\n", nv);
    write_chunk_header(fA3D, TRI_MESH_VERTEX_LIST_ID, node->GetName(),
	                   4+nv*12);
    fwrite(&nv, sizeof(int), 1, fA3D);
    for (int i=0; i<nv; i++)
	{
      v = valid_vertex[i];
	  fprintf(fTXT, "Vertex %d : x=%f,  y=%f,  z=%f\n", i, v.x, v.y, v.z);
	  fwrite(&v.x, sizeof(float), 1, fA3D);
	  fwrite(&v.y, sizeof(float), 1, fA3D);
	  fwrite(&v.z, sizeof(float), 1, fA3D);
	}
  }

  
  // scrittura del chunk delle facce geometriche
  fprintf(fTXT, "Number of triangles (non optimized): %d\n", nt);
  build_valid_face(mesh, valid_faces, &nt);
  fprintf(fTXT, "Number of triangles (optimized): %d\n", nt);
  write_chunk_header(fA3D, TRI_MESH_FACES_LIST_ID, node->GetName(),
	                 4+nt*16);
  fwrite(&nt, sizeof(int), 1, fA3D);
  for (j=0; j<nt; j++)
  {
	tf1=vertex_hash[mesh->faces[valid_faces[j]].v[vx1]];
	tf2=vertex_hash[mesh->faces[valid_faces[j]].v[vx2]];
	tf3=vertex_hash[mesh->faces[valid_faces[j]].v[vx3]];
    fprintf(fTXT, "Face %d : a=%d,  b=%d, c=%d,  sg=%X\n",
	        j, tf1, tf2, tf3, mesh->faces[valid_faces[j]].smGroup);
	fwrite(&tf1, sizeof(int), 1, fA3D);
	fwrite(&tf2, sizeof(int), 1, fA3D);
	fwrite(&tf3, sizeof(int), 1, fA3D);
	fwrite(&mesh->faces[valid_faces[j]].smGroup, sizeof(int), 1, fA3D);
  }


  // scrittura dei vertici texture
  fprintf(fTXT, "Numero di vertici texture (non optimized): %d\n", numTEXvert);
  build_valid_texture_vertex(mesh, uv, hash_uv, &numTEXvert);
  fprintf(fTXT, "Numero di vertici texture (optimized): %d\n", numTEXvert);
  if (numTEXvert>0)
  {
    write_chunk_header(fA3D, TRI_MESH_TEXTURE_VERTEX_LIST_ID, node->GetName(),
		               4+numTEXvert*8);
    fwrite(&numTEXvert, sizeof(int), 1, fA3D);
    for (j=0; j<numTEXvert; j++)
    {
	   tv = uv[j];
       fprintf(fTXT, "tex_vert %d : u=%f,  v=%f\n", j, tv.x, tv.y);
	   fwrite(&tv.x, sizeof(float), 1, fA3D);
	   fwrite(&tv.y, sizeof(float), 1, fA3D);
	 }
  }

  if (numTEXvert>0)
  {
    // scrittura facce texturizzate (le scrivo solo se esistono
	// vertici texture !!!)
	int mat_mod = 1;
	if (materiale) mat_mod=materiale->NumSubMtls();
	if (mat_mod==0) mat_mod=1;

    fprintf(fTXT, "Numero di facce texture : %d\n", nt);
    write_chunk_header(fA3D, TRI_MESH_TEXTURE_FACES_LIST_ID,
		               node->GetName(), 4+nt*16);
    fwrite(&nt, sizeof(int), 1, fA3D);

	int g_id_ref;
	g_id_ref = GetMtl_GLOBAL_ID(materiale);
	for (j=0; j<nt; j++)
	{
       int face_g_id = g_id_ref + (mesh->faces[j].getMatID() % mat_mod);
	   // fprintf(fTXT, "tex_face %d : t1=%d,  t2=%d,  t3=%d,  g_id=%d,  id=%d\n",
       // j, mesh->tvFace[j].t[vx1], mesh->tvFace[j].t[vx2],
       // mesh->tvFace[j].t[vx3], face_g_id, mesh->faces[j].getMatID());
	   tf1=hash_uv[mesh->tvFace[valid_faces[j]].t[vx1]];
	   tf2=hash_uv[mesh->tvFace[valid_faces[j]].t[vx2]];
	   tf3=hash_uv[mesh->tvFace[valid_faces[j]].t[vx3]];
       fprintf(fTXT, "TFace %d : a=%d,  b=%d, c=%d\n", j, tf1, tf2, tf3);
	   fwrite(&tf1, sizeof(int), 1, fA3D);
	   fwrite(&tf2, sizeof(int), 1, fA3D);
	   fwrite(&tf3, sizeof(int), 1, fA3D);
	   fwrite(&face_g_id, sizeof(int), 1, fA3D);
	}
  }

  if (makeADO)
  {
    fprintf(fADO, "  object %c%s%c\n  {\n", '"', node->GetName(), '"');
    fprintf(fADO, "    lod_levels=%c0%c;\n  }\n\n", '"', '"');
  }

  //------------------------
  // ESPORTAZIONE KEYFRAMER
  //------------------------
  Control *c;
  int size_key;

  // NB: per gli oggetti mesh e quant'altre tipologie di
  // oggetti che possono essere linkati (ovvero dove e'
  // possibile implmenetare gerarchie), ad esempio patch
  // di Bezier, esporto SEMPRE una key di posizione, una
  // di rotazione ed una di scaling
  
  // esportiamo l'animazione della posizione dell'oggetto
  // se ci sono un numero di key > 0


  // POSITION CONTROLLER
  c=node->GetTMController()->GetPositionController();
  if ((c) && (c->NumKeys()>0))
  {
	 if (IsTCBControl(c)) size_key=36;
	 else
	 if (IsBezierControl(c)) size_key=40;
	 else size_key=16;
	 fprintf(fTXT, "Object position track present.");
     write_chunk_header(fA3D, POSITION_TRACK_ID,
	                    node->GetName(), 1+4+c->NumKeys()*size_key);
     export_Point3_track(c, fA3D);
  }
  // esportiamo comunque una key di posizione TCB
  else
  {
	fprintf(fTXT, "Object position track present. (1 key case)");
	size_key=36;
    write_chunk_header(fA3D, POSITION_TRACK_ID,
	                   node->GetName(), 1+4+1*size_key);
    export_1Key_Point3_track(c, fA3D);
  }


  // ROTATION CONTROLLER
  c=node->GetTMController()->GetRotationController();
  if ((c) && (c->NumKeys()>0))
  {
	 if (IsTCBControl(c)) size_key=40;
	 else size_key=20;
	 fprintf(fTXT, "Object rotation track present.");
     write_chunk_header(fA3D, ROTATION_TRACK_ID,
	                    node->GetName(), 1+4+c->NumKeys()*size_key);
     export_Rot_track(c, fA3D);
  }
  // esportiamo comunque una key di rotazione TCB
  else
  {
	fprintf(fTXT, "Object rotation track present. (1 key case)");
	size_key=40;
    write_chunk_header(fA3D, ROTATION_TRACK_ID,
	                   node->GetName(), 1+4+1*size_key);
    export_1Key_Rot_track(c, fA3D);
  }

  
  // SCALE CONTROLLER
  c=node->GetTMController()->GetScaleController();
  if ((c) && (c->NumKeys()>0))
  {
	 if (IsTCBControl(c)) size_key=36;
	 else
	 if (IsBezierControl(c)) size_key=40;
	 else size_key=16;
	 fprintf(fTXT, "Object scaling track present.");
     write_chunk_header(fA3D, SCALE_TRACK_ID,
	                    node->GetName(), 1+4+c->NumKeys()*size_key);
     export_scale_track(c, fA3D);
  }
  // esportiamo comunque una key di scaling TCB
  else
  {
	fprintf(fTXT, "Object scaling track present. (1 key case)");
	size_key=36;
    write_chunk_header(fA3D, SCALE_TRACK_ID,
	                   node->GetName(), 1+4+1*size_key);
    export_1Key_scale_track(c, fA3D);
  }
  if (needDel) delete tri;


//************************************************************
//************************************************************
//            ESPORTAZIONE OBJECT SPACE MODIFIER
//************************************************************
//************************************************************

  // ESPORTAZIONE TWIST, BEND, etc
  if (has_known_modifiers==3)
  {
     int ModStackIndex;
	 char ordinal;
     Object* ObjectPtr;
     ObjectPtr = node->GetObjectRef();
	 ordinal=0;
     while ((ObjectPtr) && (ObjectPtr->SuperClassID() == GEN_DERIVOB_CLASS_ID))
	 {
       IDerivedObject *DerivedObjectPtr = (IDerivedObject *)(ObjectPtr);
       ModStackIndex = 0;
       while (ModStackIndex < DerivedObjectPtr->NumModifiers())
	   {
         Modifier* ModifierPtr = DerivedObjectPtr->GetModifier(ModStackIndex);

		 // TWIST OSM
         if ((ModifierPtr->ClassID() == Class_ID(TWISTOSM_CLASS_ID, 1)) ||
		     (ModifierPtr->ClassID() == Class_ID(TWISTOSM_CLASS_ID, 0)))
		 {
            fprintf(fTXT, "Twist OSM found at order %d...\n", ordinal);
			export_OSM_twist(ModifierPtr, ordinal, node);
            fprintf(fTXT, "OK!\n");
			ordinal++;
		 }
		 else
		 // RIPPLE OSM
		 if (ModifierPtr->ClassID() == Class_ID(SINEWAVE_OMOD_CLASS_ID, 0))
		 {
            fprintf(fTXT, "Ripple OSM found at order %d...\n", ordinal);
			export_OSM_ripple(ModifierPtr, ordinal, node);
            fprintf(fTXT, "OK!\n");
			fflush(fTXT);
			ordinal++;
		 }
		 else
		 // BEND OSM
		 if (ModifierPtr->ClassID() == Class_ID(BENDOSM_CLASS_ID, 0))
		 {
            fprintf(fTXT, "Bend OSM found at order %d...\n", ordinal);
			export_OSM_bend(ModifierPtr, ordinal, node);
            fprintf(fTXT, "OK!\n");
			fflush(fTXT);
			ordinal++;
		 }
		 else
		 // MELT OSM
		 if (ModifierPtr->ClassID() == Class_ID(MELT_ID1, MELT_ID2))
		 {
            fprintf(fTXT, "Melt OSM found at order %d...\n", ordinal);
			export_OSM_melt(ModifierPtr, ordinal, node);
            fprintf(fTXT, "OK!\n");
			fflush(fTXT);
			ordinal++;
		 }
		 else
		 // STRETCH OSM
		 if (ModifierPtr->ClassID() == Class_ID(STRETCHOSM_CLASS_ID1, STRETCHOSM_CLASS_ID2))
		 {
            fprintf(fTXT, "Stretch OSM found at order %d...\n", ordinal);
			export_OSM_stretch(ModifierPtr, ordinal, node);
            fprintf(fTXT, "OK!\n");
			fflush(fTXT);
			ordinal++;
		 }
		 else
		 // TAPER OSM
		 if (ModifierPtr->ClassID() == Class_ID(TAPEROSM_CLASS_ID, 0))
		 {
            fprintf(fTXT, "Taper OSM found at order %d...\n", ordinal);
			export_OSM_taper(ModifierPtr, ordinal, node);
            fprintf(fTXT, "OK!\n");
			fflush(fTXT);
			ordinal++;
		 }
		 else
		 // FFD4x4x4, FFD3x3x3, FFD2x2x2
		 if ((ModifierPtr->ClassID() == FFD44_CLASS_ID) ||
			 (ModifierPtr->ClassID() == FFD33_CLASS_ID) ||
			 (ModifierPtr->ClassID() == FFD22_CLASS_ID))
		 {
            fprintf(fTXT, "FFD(irule!) OSM found at order %d...\n", ordinal);
			export_OSM_ffd(ModifierPtr, ordinal, node);
            fprintf(fTXT, "OK!\n");
			fflush(fTXT);
			ordinal++;
		 }
		 else
		 // NOISE OSM
         if (ModifierPtr->ClassID() == Class_ID(NOISEOSM_CLASS_ID, 0))
		 {
            fprintf(fTXT, "Noise(irule!) OSM found at order %d...\n", ordinal);
			export_OSM_noise(ModifierPtr, ordinal, node);
            fprintf(fTXT, "OK!\n");
			fflush(fTXT);
			ordinal++;
		 }
         ModStackIndex++;
	   }
       ObjectPtr = DerivedObjectPtr->GetObjRef();
	 }
  }
  else
  // ESPORTAZIONE PHYSIC MODIFIER (if doppio ridondante ma per sicurezza)
  if ((physmod) && (has_known_modifiers==2))
  {
     IPhysiqueExport *phyExport = (IPhysiqueExport *)(physmod->GetInterface(I_PHYINTERFACE));
     if (phyExport)
	 {
       // create a ModContext Export Interface for the specific node of the Physique Modifier
       IPhyContextExport *mcExport = (IPhyContextExport *)phyExport->GetContextInterface(node);
       if (mcExport)
	   {
		 fflush(fA3D);
		 fpos=ftell(fA3D);
         type_phys=0;
         // type_phys + numero_vertici
		 size_phys=4+4;

         write_chunk_header(fA3D, PHYSIC_MODIFIER_ID,
                     node->GetName(),
	                 0);
		 fwrite(&type_phys, sizeof(int), 1, fA3D);
		 type_phys=os.obj->NumPoints();
		 fwrite(&type_phys, sizeof(int), 1, fA3D);

         // we convert all vertices to Rigid
         mcExport->ConvertToRigid(TRUE);
         // compute the transformed Point3 at time t
         for (int i = 0; i < os.obj->NumPoints();  i++)
         {
           IPhyVertexExport *vtxExport = mcExport->GetVertexInterface(i);
           if (vtxExport)
           {
             // need to check if vertex has blending
		     if (vtxExport->GetVertexType() & BLENDED_TYPE)
		     {
			    IPhyBlendedRigidVertex *vtxBlend = (IPhyBlendedRigidVertex *)vtxExport;

			    Point3 BlendP(0.0f, 0.0f, 0.0f);
			    for (int n = 0; n < vtxBlend->GetNumberNodes(); n++)
				{
			       INode *Bone = vtxBlend->GetNode(n);
                   Point3 Offset = vtxBlend->GetOffsetVector(n);
			       float Weight = vtxBlend->GetWeight(n);
        		   BlendP += (Bone->GetNodeTM(0) * Offset) * Weight;
				}
				fprintf(fTXT, "Vertex %d BLENDED_TYPE: %f, %f, %f\n", i, BlendP.x, BlendP.y, BlendP.z);
			    // set the Point of the object (to test the export is correct)
                // os->obj->SetPoint(i, BlendP);
                mcExport->ReleaseVertexInterface(vtxExport);
                vtxExport = NULL;
			  }
		      else
		      {
			    IPhyRigidVertex *vtxNoBlend = (IPhyRigidVertex *)vtxExport;
                INode *Bone = vtxNoBlend->GetNode();
                Point3 Offset = vtxNoBlend->GetOffsetVector();
				fprintf(fTXT, "Vertex %d RIGID: %f, %f, %f %s\n", i, Offset.x, Offset.y, Offset.z, Bone->GetName());
		        fwrite(&Offset.x, sizeof(float), 1, fA3D);
		        fwrite(&Offset.y, sizeof(float), 1, fA3D);
		        fwrite(&Offset.z, sizeof(float), 1, fA3D);
			    write_string0(fA3D, Bone->GetName());
				size_phys+=3*sizeof(float)+strlen(Bone->GetName())+1;
			    // set the Point of the object (to test the export is correct)
                // os->obj->SetPoint(i, Bone->GetNodeTM(t) * Offset);
              	mcExport->ReleaseVertexInterface(vtxExport);
               	vtxExport = NULL;
			  }
		   }
		 }
         phyExport->ReleaseContextInterface(mcExport);
		 fflush(fA3D);
		 fseek(fA3D, fpos, SEEK_SET);
         write_chunk_header(fA3D, PHYSIC_MODIFIER_ID,
                     node->GetName(),
	                 size_phys);
		 fflush(fA3D);
		 fseek(fA3D, 0, SEEK_END);
	   }
       physmod->ReleaseInterface(I_PHYINTERFACE, phyExport);
	 }
  }
  else
  // ESPORTAZIONE Skin MODIFIER
  if ((skinmod) && (has_known_modifiers==5))
  {
	ISkin *pSkin = (ISkin*)skinmod->GetInterface(I_SKIN);
	if(pSkin == NULL)
	{
	   fprintf(fTXT, "pSkin NULL!\n");
	   return;
	}
	ISkinContextData *pSkinContext = pSkin->GetContextInterface(node);
	if(pSkinContext == NULL)
	{
	   fprintf(fTXT, "pSkinContext NULL!\n");
	   return;
	}

	fflush(fA3D);
	fpos=ftell(fA3D);
    write_chunk_header(fA3D, PHYSIC_MODIFIER_ID, node->GetName(), 0);

	num_bones_names=pSkin->GetNumBones();
	numBones_short=(short int)num_bones_names;
	fprintf(fTXT, "Num Bones: %d\n", numBones_short);
	fwrite(&numBones_short, sizeof(short int), 1, fA3D);
	size_skin=2;  // num bones
    for(i=0; i<num_bones_names; i++)
	{
	   strcpy(bones_names[i], pSkin->GetBone(i)->GetName());
       write_string0(fA3D, bones_names[i]);
	   fprintf(fTXT, "  Bone Name %d: %s\n", i, bones_names[i]);
	   size_skin+=strlen(bones_names[i])+1; // nome della bone
	}
	int numPoints = pSkinContext->GetNumPoints();
	fprintf(fTXT, "NumPoints: %d\n", numPoints);
	fwrite(&numPoints, sizeof(int), 1, fA3D);
    size_skin+=4; // numero_vertici

	for(i=0; i<numPoints; i++)
	{
		numBones = pSkinContext->GetNumAssignedBones(i);
		numBones_short=0;
		// conto le bonez effettive usate dal vertice i-esimo
        for(j=0; j<numBones; j++)
		{
           assignedBone = pSkinContext->GetAssignedBone(i, j);
           fprintf(fTXT, "Assigned bone: %d\n", assignedBone); fflush(fTXT);
		   if (assignedBone>=0) numBones_short++;
		}
	    fwrite(&numBones_short, sizeof(short int), 1, fA3D);
		size_skin+=2;
		fprintf(fTXT, "NumBones assigned for vertex %d : %d\n", i, numBones_short);
		fflush(fTXT);
		// esporto i pesi per il vertic i-esimo
		for(j=0; j<numBones; j++)
		{
			assignedBone = pSkinContext->GetAssignedBone(i, j);
			if (assignedBone>=0)
			{
			   INode *pBone = pSkin->GetBone(assignedBone);
			   k=0;
			   while ((k<num_bones_names) &&
				      (strcmp(bones_names[k], pBone->GetName())!=0))
			   { k++; }
			   if (k<num_bones_names)
			   {
			     float weight = pSkinContext->GetBoneWeight(i, j);
                 fprintf(fTXT, "  Bone %d: %s, index %d, weight=%f\n",
				         j, bones_names[k], k, weight); fflush(fTXT);
			     short int short_k=(short int)k;
			     fwrite(&short_k, sizeof(short int), 1, fA3D);
			     fwrite(&weight, sizeof(float), 1, fA3D);
			     size_skin+=2+4;
			   }
			}
		}
	}
	fflush(fA3D);
	fseek(fA3D, fpos, SEEK_SET);
    write_chunk_header(fA3D, SKIN_MODIFIER_ID, node->GetName(), size_skin);
    fflush(fA3D);
	fseek(fA3D, 0, SEEK_END);
	skinmod->ReleaseInterface(I_SKIN, pSkin);
  }

  fprintf(fTXT, "\n\n");
  fflush(fTXT);
  fflush(fA3D);
  delete [] valid_vertex;
  delete [] vertex_hash;
  delete [] uv;
  delete [] hash_uv;
  delete [] valid_faces;
}
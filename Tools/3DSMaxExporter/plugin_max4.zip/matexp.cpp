
#include "SceneExport.h"
#include "A3Dfile.h"
#include "stdmtl.h"


int SkeletonExporter::GetSize_of_material_list_chunk (void)
{
   int result=0, i, j;
   Mtl* mtl, *subm;

   for (i=0; i<nmat; i++)
   {
	  mtl=materiali[i].m;
      if (mtl->ClassID() == Class_ID(MULTI_CLASS_ID, 0))
	  {
         for (j=0; j<mtl->NumSubMtls(); j++)
		 {
           subm=mtl->GetSubMtl(j);
		   // aggiungo l'id + lunghezza nome + '\0'
		   result+=sizeof(int);
		   result+=(1 + strlen(subm->GetName()));
		 }
	  }
	  else
	  {
		// aggiungo l'id + lunghezza nome + '\0'
		result+=sizeof(int);
		result+=(1 + strlen(mtl->GetName()));
	  }
   }

   // aggiungo l'id negativo che indica fine lista
   result+=sizeof(int);
   fprintf(fTXT, "Size del chunk lista materiali = %d\n", result);
   return(result);
}


int	SkeletonExporter::GetMtlID(Mtl* mtl)
{
  for (int k=0; k<nmat; k++)
  {
	if (materiali[k].m==mtl) return(k);
 }
  return(-1);
}


int	SkeletonExporter::GetMtl_GLOBAL_ID(Mtl* mtl)
{
  int g_id=0, subm;

  for (int k=0; k<nmat; k++)
  {
	if (materiali[k].m==mtl) return(g_id);
	subm=materiali[k].m->NumSubMtls();
	if (subm>0)	g_id=g_id+subm;
	else g_id=g_id+1;
  }
  return(-1);
}


void SkeletonExporter::count_add_materials(INode *node)
{
  Mtl *mm;
  int w, flag;

  mm=node->GetMtl();
  flag=0;

  if (mm)
  {
	for (w=0; w<nmat; w++)
	{
	  if (materiali[w].m==mm) flag=1;
	}
    if (flag==0)  // materiale non ancora inserito
	{
      materiali[nmat].m=mm;
	  strcpy(materiali[nmat].name, mm->GetName());
	  nmat++;
	}
  }

  // For each child of this node, we recurse into ourselves 
  // and increment the counter until no more children are found.
  for (int c = 0; c < node->NumberOfChildren(); c++)
  {
 	count_add_materials(node->GetChildNode(c));
  }
}


void SkeletonExporter::dump_material(Mtl* mtl)
{
  Color col;
  int i, j;

  if (!mtl) return;

  TSTR className;
  mtl->GetClassName(className);

  // se in realta' il materiale e' un Multi/Sub_Object, ovvero
  // e' un materiale che contiene sottomateriali non lo devo
  // dumpare (nome, mappe, ecc), ma devo dumpare i suoi
  // sottomateriali; su file (script, ascii, binario) scrivo
  // solo quando raggiungo materiali standard !!!
  if (mtl->ClassID() == Class_ID(MULTI_CLASS_ID, 0))
  {
     fprintf(fTXT, "Materiale composto, numero sotto-materiali : %d\n", mtl->NumSubMtls());
     for (j=0; j<mtl->NumSubMtls(); j++)
	 {
	   Mtl* subMtl = mtl->GetSubMtl(j);
	   if (subMtl) { dump_material(subMtl); }
	 }
  }
  else if (mtl->ClassID() == Class_ID(DMTL_CLASS_ID, 0))
  {
    // scrivo nella lista dei materiali la coppia
	// (global_id, nome)
	fwrite(&global_id, sizeof(int), 1, fA3D);
	write_string0(fA3D, mtl->GetName());

    // materiale standard : dumpo tutte le info	
	fprintf(fTXT, "Material Global ID = %d\n", global_id);
	global_id++;

    fprintf(fTXT, "Material name : %s \n", mtl->GetName());
    if (makeADM) fprintf(fADM, "  material %c%s%c \n  {\n", '"', mtl->GetName(), '"');
    //fprintf(fTXT, "Material class : %s \n", className);

	StdMat* stdm = (StdMat*)mtl;
	fprintf(fTXT,"Opacity : %d%c \n", (int)(100*stdm->GetOpacity(0)), '%');

	if (stdm->GetTwoSided()) fprintf(fTXT, "Two sided : yes \n"); 
	else fprintf(fTXT, "Two sided : no \n"); 

	if (stdm->GetWire()) fprintf(fTXT, "Wireframe : yes");

	for (i=0; i<mtl->NumSubTexmaps(); i++)
	{
      Texmap* subTex = mtl->GetSubTexmap(i);
      float amt = 1.0f;
      if (subTex) 
	  {
         if (!stdm->MapEnabled(i)) continue;
	     amt=stdm->GetTexmapAmt(i, 0);
	     dump_texture(subTex, mtl->ClassID(), i, amt);
	  }
	}

    fprintf(fTXT, "\n\n");
    if (makeADM)
	{
	  // se ci sono sia texture che envmap scripto il mixing tra
	  // le due mappe
	   if (stdm->MapEnabled(ID_DI) && stdm->MapEnabled(ID_RL))
	      fprintf(fADM, "    mapsmixtype=%cBLEND50%c;\n", '"', '"');
	   
	   // se c'e' mappa di autoilluminazione metto NONE come
	   // fattore di mixing nelle luci
	   if (stdm->MapEnabled(ID_SI))
	      fprintf(fADM, "    lightmixtype=%cNONE%c;\n", '"', '"');
	   else
	      fprintf(fADM, "    lightmixtype=%cBLEND50%c;\n", '"', '"');

	  // scrivo una trasparenza numerica solo se il materiale non
	  // ha mappa di trasparenza e ha una opacit� non massima
	  if ( (
		     (stdm->GetOpacity(0)<1) &&
		     (!stdm->MapEnabled(ID_OP))
		    ) ||
		    (material_have_transparency_track(mtl))
         )
	  {
         if (stdm->GetTransparencyType()==TRANSP_ADDITIVE)
		     fprintf(fADM, "    trasparency_type=%cADD%c;\n", '"', '"');
		 else
		     fprintf(fADM, "    trasparency_type=%cALPHA%c;\n", '"', '"');
	     fprintf(fADM, "    trasparency_amount=%c%d%c;\n", '"', (int)(255*stdm->GetOpacity(0)), '"');

	  }
      /*
	  // Da attivare per esportare per l'engio raytrazza
	  col=mtl->GetDiffuse();
	  fprintf(fADM, "    diffuse_r=%c%d%c;\n", '"', (int)(col.r*255), '"');
	  fprintf(fADM, "    diffuse_g=%c%d%c;\n", '"', (int)(col.g*255), '"');
	  fprintf(fADM, "    diffuse_b=%c%d%c;\n", '"', (int)(col.b*255), '"');
	  fprintf(fADM, "    diffuse_kd=%c1.0%c;\n", '"', '"');
	  col=mtl->GetSpecular();
	  fprintf(fADM, "    specular_r=%c%d%c;\n", '"', (int)(col.r*255), '"');
	  fprintf(fADM, "    specular_g=%c%d%c;\n", '"', (int)(col.g*255), '"');
	  fprintf(fADM, "    specular_b=%c%d%c;\n", '"', (int)(col.b*255), '"');
	  fprintf(fADM, "    specular_ks=%c1.0%c;\n", '"', '"');
	  fprintf(fADM, "    refraction_index=%c%f%c;\n", '"', stdm->GetIOR(0), '"');
	  fprintf(fADM, "    glossiness=%c%f%c;\n", '"', stdm->GetShininess(0), '"');
	  */
      fprintf(fADM, "  }\n\n");
	}
  }

  fflush(fTXT);
  return;
}


// For a standard material, this will give us the meaning of a map
// givien its submap id.
TCHAR* SkeletonExporter::getmapID(Class_ID cid, int subNo)
{
	static TCHAR buf[50];
	
	if (cid == Class_ID(0,0))
	{
	  strcpy(buf, "ENVMAP");
	}
	else if (cid == Class_ID(DMTL_CLASS_ID, 0)) 
	{
		switch (subNo)
		{
		  case ID_AM: strcpy(buf, "MAP_AMBIENT"); break;
		  case ID_DI: strcpy(buf, "MAP_DIFFUSE"); break;
		  case ID_SP: strcpy(buf, "MAP_SPECULAR"); break;
		  case ID_SH: strcpy(buf, "MAP_SHINE"); break;
		  case ID_SS: strcpy(buf, "MAP_SHINESTRENGTH"); break;
		  case ID_SI: strcpy(buf, "MAP_SELFILLUM"); break;
		  case ID_OP: strcpy(buf, "MAP_OPACITY"); break;
		  case ID_FI: strcpy(buf, "MAP_FILTERCOLOR"); break;
		  case ID_BU: strcpy(buf, "MAP_BUMP"); break;
		  case ID_RL: strcpy(buf, "MAP_REFLECT"); break;
		  case ID_RR: strcpy(buf, "MAP_REFRACT"); break;
		}
	}
	else { strcpy(buf, "MAP_GENERIC");	}
	return buf;
}


void SkeletonExporter::dump_texture(Texmap* tex, Class_ID cid, int subNo, float amt)
{
	if (!tex) return;
	
	TSTR className;
	tex->GetClassName(className);
	
	fprintf(fTXT,"Map ID : %s \n", getmapID(cid, subNo));
	fprintf(fTXT,"Map name : %s \n", tex->GetName());
	fprintf(fTXT,"Map class name : %s \n", className);
	
	// Is this a bitmap texture?
	// We know some extra bits 'n pieces about the bitmap texture
	if (tex->ClassID() == Class_ID(BMTEX_CLASS_ID, 0)) 
	{
	  BitmapTex *bmptex=(BitmapTex *)tex;
	  TSTR mapName = bmptex->GetMapName();
	  fprintf(fTXT,"Map filename: %s \n", mapName);
	  if (makeADM)
	  {
         StdUVGen *uvgen=(StdUVGen *)NULL;
		 uvgen=bmptex->GetUVGen();
	     if (uvgen)
		    fprintf(fTXT,"Mapping type: %d\n", uvgen->GetCoordMapping(0));
         fprintf(fTXT,"Mapping type2: %d\n", tex->GetUVWSource());
         fprintf(fTXT,"GetMapChannel: %d\n", tex->GetMapChannel());
         
		// nel caso ci fosse una mappa env
		if (strcmp(getmapID(cid, subNo), "MAP_REFLECT")==0)
		   fprintf(fADM, "    envmap=%c%s%c;\n", '"', mapName, '"');

		// nel caso ci fosse una texture
		if (strcmp(getmapID(cid, subNo), "MAP_DIFFUSE")==0)
		{
		   fprintf(fADM, "    texture=%c%s%c;\n", '"', mapName, '"');
		   // mi ricavo i fattori di scala per le UV (Hellbender SUXX)
		   if (uvgen)
		   {
			  if (uvgen->GetUScl(0) != 1)
		         fprintf(fADM, "    u_tile=%c%f%c;\n", '"', uvgen->GetUScl(0), '"');
			  if (uvgen->GetVScl(0) != 1)
		         fprintf(fADM, "    v_tile=%c%f%c;\n", '"', uvgen->GetVScl(0), '"');
		   }
		}

		// nel caso ci fosse una mappa di trasparenza
		if (strcmp(getmapID(cid, subNo), "MAP_OPACITY")==0)
		   fprintf(fADM, "    trasparency_type=%c%s%c;\n", '"', mapName, '"');
	  }
	}
}


BOOL SkeletonExporter::material_have_transparency_track(Mtl* mtl)
{
  StdMat *stdm;
  Control *c;

  if (mtl->ClassID() == Class_ID(DMTL_CLASS_ID, 0))
  {
	stdm = (StdMtl*)mtl;
    IParamBlock2 *ip2;
	int npb=mtl->NumParamBlocks();
	for (int h=0; h<npb; h++)
	{
	  ip2 = mtl->GetParamBlock(h);
	  if (ip2)
	  {
		ParamBlockDesc2* pd2=ip2->GetDesc();
		int np=ip2->NumParams();
        for (int pp=0; pp<np; pp++)
		{
			// opacity
			if ((h==1) && (pp==1))
			{
				c=(Control *)NULL;
                c=ip2->GetController(1);
			    if ((c) && (c->NumKeys()>0)) return(TRUE);
				else return(FALSE);
			}
		}
	  }
	}
  }
  return(FALSE);
}


void SkeletonExporter::dump_material_tracks(Mtl* mtl)
{
  Control *c;
  StdMtl* stdm;
  int size_key;

  if (!mtl) return;
/*
  // se in realta' il materiale e' un Multi/Sub_Object, ovvero
  // e' un materiale che contiene sottomateriali non lo devo
  // dumpare (tracce di opacit� etc), ma devo dumpare i suoi
  // sottomateriali; su file (script, ascii, binario) scrivo
  // solo quando raggiungo materiali standard !!!
  if (mtl->ClassID() == Class_ID(MULTI_CLASS_ID, 0))
  {
     for (j=0; j<mtl->NumSubMtls(); j++)
	 {
	   Mtl* subMtl = mtl->GetSubMtl(j);
	   if (subMtl) { dump_material(subMtl); }
	 }
  }
  else */
  if (mtl->ClassID() == Class_ID(DMTL_CLASS_ID, 0))
  {
	stdm = (StdMtl*)mtl;
    IParamBlock2 *ip2;
	int npb=mtl->NumParamBlocks();
	fprintf(fTXT, "Num of param2 blocks: %d\n", npb);
	fflush(fTXT);
	for (int h=0; h<npb; h++)
	{
	  ip2 = mtl->GetParamBlock(h);
	  if (ip2)
	  {
		ParamBlockDesc2* pd2=ip2->GetDesc();
//		fprintf(fTXT, "Name: %s\n", pd2->int_name);
		int np=ip2->NumParams();
//		fprintf(fTXT, "parameter block %d: number of params = %d\n", h, np);
        for (int pp=0; pp<np; pp++)
		{
//			fprintf(fTXT, "parametro %d: %s\n", pp, pd2->paramdefs[pp].int_name);
			// opacity
			if ((h==1) && (pp==1))
			{
				c=(Control *)NULL;
                c=ip2->GetController(1);
			    if ((c) && (c->NumKeys()>0))
				{
                   if (IsTCBControl(c)) size_key=28;
	               else
	               if (IsBezierControl(c)) size_key=16;
	               else size_key=8;
	               fprintf(fTXT, "Material %s:  opacity track present.\n", mtl->GetName());
                   write_chunk_header(fA3D, MATERIAL_OPACITY_TRACK_ID,
	                                  mtl->GetName(), 1+4+c->NumKeys()*size_key);
//				   fprintf(fTXT, "num_key=%d\n", c->NumKeys());
				   export_float_track(c, 255, fA3D);
				}
			}
		}
	  }
	}
  }

  return;
}


void SkeletonExporter::export_materials(void)
{
  int meno1=-1, size;
  int i;

  nmat=0;
  count_add_materials(ip->GetRootNode());
  fprintf(fTXT, "Material list \n");

  int numMtls = nmat;
  fprintf(fTXT, "numero di materiali %d\n", numMtls);

  size=GetSize_of_material_list_chunk();
  write_chunk_header(fA3D, SCENE_MATERIAL_LIST_ID, "Scene Root", size);

  global_id=0;
  for (i=0; i<numMtls; i++) 
  {
 	dump_material(materiali[i].m);
  }
  // segnalo la fine del chunk lista materiali mettendo un
  // id negativo
  fwrite(&meno1, sizeof(int), 1, fA3D);

  for (i=0; i<numMtls; i++) 
  {
 	dump_material_tracks(materiali[i].m);
  }
}
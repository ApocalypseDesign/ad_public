
#include "SceneExport.h"
#include "A3Dfile.h"

void SkeletonExporter::export_omni_light(INode *node)
{
  TimeValue t = 0;
  Control *c;
  int size_key;

  ObjectState os = node->EvalWorldState(t);
  if (!os.obj) return;  // per sicurezza

  GenLight* light = (GenLight*)os.obj;
  struct LightState ls;
  Interval valid = FOREVER;
  Interval animRange = ip->GetAnimRange();

  light->EvalLightState(t, valid, &ls);
  switch (ls.type)
  {
    case OMNI_LGT : fprintf(fTXT, "Omni light found\n");
		            write_chunk_header(fA3D, OMNI_LIGHT_ID, node->GetName(), 24);
		            write_chunk_header(fRAY, OMNI_LIGHT_ID, node->GetName(), 24);
		            break;

    case SPOT_LGT : fprintf(fTXT, "Spot light found; bin data won be saved, spotlight not yet supported");
		            break;
  }

  fprintf(fTXT, "Name : %s\n", node->GetName());
  
  // salviamo il colore
  fprintf(fTXT, "Color : R=%f, G=%f, B=%f\n", ls.color.r, ls.color.g, ls.color.b);
  fwrite(&ls.color.r, sizeof(float), 1, fA3D);
  fwrite(&ls.color.g, sizeof(float), 1, fA3D);
  fwrite(&ls.color.b, sizeof(float), 1, fA3D);
  fwrite(&ls.color.r, sizeof(float), 1, fRAY);
  fwrite(&ls.color.g, sizeof(float), 1, fRAY);
  fwrite(&ls.color.b, sizeof(float), 1, fRAY);

  float near_radius, far_radius;

  // NO far + NO near
  if ((!light->GetUseAttenNear()) && (!light->GetUseAtten()))
  {
     far_radius=near_radius=999999;
  }
  else
  // NO far + SI near
  if ((light->GetUseAttenNear()) && (!light->GetUseAtten()))
  {
     near_radius=light->GetAtten(0, ATTEN1_START, valid);
	 far_radius=999999;
  }
  else
  // SI far + NO near
  if ((!light->GetUseAttenNear()) && (light->GetUseAtten()))
  {
     far_radius=light->GetAtten(0, ATTEN_START, valid);
     near_radius=far_radius;
  }
  // SI far + SI near
  if ((light->GetUseAttenNear()) && (light->GetUseAtten()))
  {
     near_radius=light->GetAtten(0, ATTEN1_START, valid);
	 far_radius=light->GetAtten(0, ATTEN_START, valid);
  }
    

  fprintf(fTXT, "Intensity : %f\n", ls.intens);
  if (makeADL)
  {
    fprintf(fADL, "  light %c%s%c\n  {\n", '"', node->GetName(), '"');
    fprintf(fADL, "    texture=%cNONE%c;\n", '"', '"');
    fprintf(fADL, "    scale_x=%c160%c;\n", '"', '"');
    fprintf(fADL, "    scale_y=%c160%c;\n", '"', '"');
    fprintf(fADL, "    near_radius=%c%f%c;\n", '"', near_radius, '"');
    fprintf(fADL, "    far_radius=%c%f%c;\n", '"', far_radius, '"');
	fprintf(fADL, "  }\n\n");
  }

  
  // salviamo la posizione nel mondo
  Matrix3 pivot = node->GetNodeTM(t);
  Point3 row = pivot.GetRow(3);
  fprintf(fTXT, "World position : x=%f, y=%f, z=%f\n", row.x, row.y, row.z);
  fwrite(&row.x, sizeof(float), 1, fA3D);
  fwrite(&row.y, sizeof(float), 1, fA3D);
  fwrite(&row.z, sizeof(float), 1, fA3D);
  fwrite(&row.x, sizeof(float), 1, fRAY);
  fwrite(&row.y, sizeof(float), 1, fRAY);
  fwrite(&row.z, sizeof(float), 1, fRAY);

  
  // esportazione tracce di posizione
  c=node->GetTMController()->GetPositionController();
  if ((c) && (c->NumKeys()>0))
  {
	if (IsTCBControl(c)) size_key=36;
    else
	if (IsBezierControl(c)) size_key=40;
	else size_key=16;
	fprintf(fTXT, "Light position track present.");
    write_chunk_header(fA3D, LIGHT_POSITION_TRACK_ID,
                       node->GetName(), 1+4+c->NumKeys()*size_key);
    export_Point3_track(c, fA3D);
    write_chunk_header(fRAY, LIGHT_POSITION_TRACK_ID,
                       node->GetName(), 1+4+c->NumKeys()*size_key);
    export_Point3_track(c, fRAY);
  }


  // esportazione tracce di colore
  c=light->GetColorControl();
  if ((c) && (c->NumKeys()>0))
  {
	if (IsTCBControl(c)) size_key=36;
	else
	if (IsBezierControl(c)) size_key=40;
	else size_key=16;
	fprintf(fTXT, "Light color track present.");
    write_chunk_header(fA3D, COLOR_TRACK_ID,
                       node->GetName(), 1+4+c->NumKeys()*size_key);
    export_Point3_track(c, fA3D);
    write_chunk_header(fRAY, COLOR_TRACK_ID,
                       node->GetName(), 1+4+c->NumKeys()*size_key);
    export_Point3_track(c, fRAY);
  }

  fprintf(fTXT, "\n\n");
}
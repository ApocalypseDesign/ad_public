//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SceneExport.rc
//
#define IDS_CLASSNAME                   1
#define IDS_PARAMETERS                  2
#define IDS_SIMPLE                      3
#define IDS_LIBDESC                     4
#define IDS_EXT_01                      5
#define IDS_SHORTDESC                   6
#define IDS_LONGDESC                    7
#define IDS_AUTHOR                      8
#define IDS_COPYRIGHT                   9
#define IDD_SKELETON_SCEXP              101
#define IDD_ABOUT                       102
#define IDI_ICON1                       103
#define IDC_SIMPLE                      1000
#define CHECK_ADM                       1000
#define IDC_OK                          1001
#define IDC_CANCEL                      1002
#define CHECK_ADL                       1003
#define CHECK_ADO                       1004
#define CHECK_ADD                       1005
#define CHECK_ADP                       1006
#define IDC_CSRATE                      1009
#define IDC_SPIN1                       1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

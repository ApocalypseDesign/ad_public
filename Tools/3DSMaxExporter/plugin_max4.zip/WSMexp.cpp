#include "SceneExport.h"
#include "extraSDK.h"
#include "A3Dfile.h"

// ***********************************************************
// ******************       VENTO      ***********************
// ***********************************************************
void SkeletonExporter::export_WSM_wind(INode *node)
{
  ObjectState os = node->EvalWorldState(0);
  if (!os.obj) return;

  INode *padre=node->GetParentNode();
  int sf;

  if ((padre) && (strcmp(padre->GetName(), "Scene Root")!=0))
  sf=strlen(padre->GetName())+1;
  else sf=0;
  
  fprintf(fTXT, "Wind space modifier found\n");
  fprintf(fTXT, "Name : %s\n", node->GetName());
  // flag padre + nome padre + strenght + decay + mapping +
  // turbolence + frequency + scale + world position
  write_chunk_header(fA3D, WIND_MODIFIER_ID, node->GetName(),
	                 4+sf+4*9);
  fwrite(&sf, sizeof(int), 1, fA3D);
  if (sf>0) write_string0(fA3D, padre->GetName());

  float turb, decay, stren, freq, scale;
  int type;
  Matrix3 mat = node->GetNodeTM(0);
  Point3 row;
  SimpleWSMObject2 *obj=(SimpleWSMObject2 *)os.obj;

  obj->pblock2->GetValue(WPB_STRENGTH, 0, stren, FOREVER);
  obj->pblock2->GetValue(WPB_DECAY, 0, decay, FOREVER);
  obj->pblock2->GetValue(WPB_TYPE, 0, type, FOREVER);
  obj->pblock2->GetValue(WPB_TURBULENCE, 0, turb, FOREVER);
  obj->pblock2->GetValue(WPB_FREQUENCY, 0, freq, FOREVER);
  obj->pblock2->GetValue(WPB_SCALE, 0, scale, FOREVER);

  fprintf(fTXT, "Strenght: %f\n", stren);
  fprintf(fTXT, "Decay: %f\n", decay);
  fprintf(fTXT, "Type: %d\n", type);
  fprintf(fTXT, "Turbulence: %f\n", turb);
  fprintf(fTXT, "Frequency: %f\n", freq);
  fprintf(fTXT, "Scale: %f\n", scale);
  fflush(fTXT);

  fwrite(&stren, sizeof(float), 1, fA3D);
  fwrite(&decay, sizeof(float), 1, fA3D);
  fwrite(&type, sizeof(int), 1, fA3D);
  fwrite(&turb, sizeof(float), 1, fA3D);
  fwrite(&freq, sizeof(float), 1, fA3D);
  fwrite(&scale, sizeof(float), 1, fA3D);

  // scrittura posizione nel mondo (riga 3)
  row = mat.GetRow(3);
  fprintf(fTXT, "World position : x=%f, y=%f, z=%f\n", row.x, row.y, row.z);
  fwrite(&row.x, sizeof(float), 1, fA3D);
  fwrite(&row.y, sizeof(float), 1, fA3D);
  fwrite(&row.z, sizeof(float), 1, fA3D);


  //------------------------
  // ESPORTAZIONE KEYFRAMER
  //------------------------
  Control *c;
  int size_key;

  // POSITION CONTROLLER
  c=node->GetTMController()->GetPositionController();
  if ((c) && (c->NumKeys()>0))
  {
	 if (IsTCBControl(c)) size_key=36;
	 else
	 if (IsBezierControl(c)) size_key=40;
	 else size_key=16;
	 fprintf(fTXT, "Object position track present.\n");
     write_chunk_header(fA3D, POSITION_TRACK_ID,
	                    node->GetName(), 1+4+c->NumKeys()*size_key);
     export_Point3_track(c, fA3D);
  }
  else
  {
	fprintf(fTXT, "Object position track present. (1 key case)\n");
	size_key=36;
    write_chunk_header(fA3D, POSITION_TRACK_ID,
	                   node->GetName(), 1+4+1*size_key);
    export_1Key_Point3_track(c, fA3D);
  }



  // ROTATION CONTROLLER
  c=node->GetTMController()->GetRotationController();
  if ((c) && (c->NumKeys()>0))
  {
	 if (IsTCBControl(c)) size_key=40;
	 else size_key=20;
	 fprintf(fTXT, "Object rotation track present.\n");
     write_chunk_header(fA3D, ROTATION_TRACK_ID,
	                    node->GetName(), 1+4+c->NumKeys()*size_key);
     export_Rot_track(c, fA3D);
  }
  else
  {
	fprintf(fTXT, "Object rotation track present. (1 key case)\n");
	size_key=40;
    write_chunk_header(fA3D, ROTATION_TRACK_ID,
	                   node->GetName(), 1+4+1*size_key);
    export_1Key_Rot_track(c, fA3D);
  }

  if (makeADP)
  {
    fprintf(fADP, "  windWSM %c%s%c\n  {\n", '"', node->GetName(), '"');
    fprintf(fADP, "      strength=%c%f%c;\n", '"', stren, '"');
    fprintf(fADP, "      decay=%c%f%c;\n", '"', decay, '"');
    fprintf(fADP, "      turbolence=%c%f%c;\n", '"', turb, '"');
    fprintf(fADP, "      frequency=%c%f%c;\n", '"', freq, '"');
    fprintf(fADP, "      scale=%c%f%c;\n", '"', scale, '"');
	fprintf(fADP, "  }\n\n");
  }
  fprintf(fTXT, "\n\n");
}



// ***********************************************************
// ******************      GRAVITA'    ***********************
// ***********************************************************
void SkeletonExporter::export_WSM_gravity(INode *node)
{
  ObjectState os = node->EvalWorldState(0);
  if (!os.obj) return;

  INode *padre=node->GetParentNode();
  int sf;

  if ((padre) && (strcmp(padre->GetName(), "Scene Root")!=0))
  sf=strlen(padre->GetName())+1;
  else sf=0;

  fprintf(fTXT, "Gravity space modifier found\n");
  fprintf(fTXT, "Name : %s\n", node->GetName());
  // flag padre + nome padre + strenght + decay + mapping +
  // world position
  write_chunk_header(fA3D, GRAVITY_MODIFIER_ID, node->GetName(),
	                 4+sf+4*6);
  fwrite(&sf, sizeof(int), 1, fA3D);
  if (sf>0) write_string0(fA3D, padre->GetName());

  float decay, stren;
  int type;
  Matrix3 mat = node->GetNodeTM(0);
  Point3 row;
  SimpleWSMObject2 *obj=(SimpleWSMObject2 *)os.obj;

  obj->pblock2->GetValue(GPB_STRENGTH, 0, stren, FOREVER);
  obj->pblock2->GetValue(GPB_DECAY, 0, decay, FOREVER);
  obj->pblock2->GetValue(GPB_TYPE, 0, type, FOREVER);

  fprintf(fTXT, "Strength: %f\n", stren);
  fprintf(fTXT, "Decay: %f\n", decay);
  fprintf(fTXT, "Type: %d\n", type);

  fwrite(&stren, sizeof(float), 1, fA3D);
  fwrite(&decay, sizeof(float), 1, fA3D);
  fwrite(&type, sizeof(int), 1, fA3D);


  // scrittura posizione nel mondo (riga 3)
  row = mat.GetRow(3);
  fprintf(fTXT, "World position : x=%f, y=%f, z=%f\n", row.x, row.y, row.z);
  fwrite(&row.x, sizeof(float), 1, fA3D);
  fwrite(&row.y, sizeof(float), 1, fA3D);
  fwrite(&row.z, sizeof(float), 1, fA3D);

  //------------------------
  // ESPORTAZIONE KEYFRAMER
  //------------------------
  Control *c;
  int size_key;

  // POSITION CONTROLLER
  c=node->GetTMController()->GetPositionController();
  if ((c) && (c->NumKeys()>0))
  {
	 if (IsTCBControl(c)) size_key=36;
	 else
	 if (IsBezierControl(c)) size_key=40;
	 else size_key=16;
	 fprintf(fTXT, "Object position track present.\n");
     write_chunk_header(fA3D, POSITION_TRACK_ID,
	                    node->GetName(), 1+4+c->NumKeys()*size_key);
     export_Point3_track(c, fA3D);
  }
  else
  {
	fprintf(fTXT, "Object position track present. (1 key case)\n");
	size_key=36;
    write_chunk_header(fA3D, POSITION_TRACK_ID,
	                   node->GetName(), 1+4+1*size_key);
    export_1Key_Point3_track(c, fA3D);
  }



  // ROTATION CONTROLLER
  c=node->GetTMController()->GetRotationController();
  if ((c) && (c->NumKeys()>0))
  {
	 if (IsTCBControl(c)) size_key=40;
	 else size_key=20;
	 fprintf(fTXT, "Object rotation track present.\n");
     write_chunk_header(fA3D, ROTATION_TRACK_ID,
	                    node->GetName(), 1+4+c->NumKeys()*size_key);
     export_Rot_track(c, fA3D);
  }
  else
  {
	fprintf(fTXT, "Object rotation track present. (1 key case)\n");
	size_key=40;
    write_chunk_header(fA3D, ROTATION_TRACK_ID,
	                   node->GetName(), 1+4+1*size_key);
    export_1Key_Rot_track(c, fA3D);
  }

  if (makeADP)
  {
    fprintf(fADP, "  gravityWSM %c%s%c\n  {\n", '"', node->GetName(), '"');
    fprintf(fADP, "      strength=%c%f%c;\n", '"', stren, '"');
    fprintf(fADP, "      decay=%c%f%c;\n", '"', decay, '"');
	fprintf(fADP, "  }\n\n");
  }
  fprintf(fTXT, "\n\n");
}




// ***********************************************************
// ******************       BOMBA      ***********************
// ***********************************************************
void SkeletonExporter::export_WSM_bomb(INode *node)
{
}
//
// Esportazioni delle tracce/animazioni in generale
//
#include "SceneExport.h"
#include "A3Dfile.h"

BOOL SkeletonExporter::IsKnownController(Control* cont)
{
	ulong partA, partB;

	if (!cont)
		return FALSE;

	partA = cont->ClassID().PartA();
	partB = cont->ClassID().PartB();

	if (partB != 0x00)
		return FALSE;

	switch (partA)
	{
	  case TCBINTERP_POSITION_CLASS_ID:
	  case TCBINTERP_ROTATION_CLASS_ID:
	  case TCBINTERP_SCALE_CLASS_ID:
	  case HYBRIDINTERP_POSITION_CLASS_ID:
	  case HYBRIDINTERP_ROTATION_CLASS_ID:
	  case HYBRIDINTERP_SCALE_CLASS_ID:
	  case LININTERP_POSITION_CLASS_ID:
	  case LININTERP_ROTATION_CLASS_ID:
	  case LININTERP_SCALE_CLASS_ID: return TRUE;
	}

	return FALSE;
}

BOOL SkeletonExporter::IsTCBControl(Control *cont)
{
  return (
		   cont->ClassID()==Class_ID(TCBINTERP_FLOAT_CLASS_ID,0) ||
		   cont->ClassID()==Class_ID(TCBINTERP_POSITION_CLASS_ID,0) ||
		   cont->ClassID()==Class_ID(TCBINTERP_ROTATION_CLASS_ID,0) ||
		   cont->ClassID()==Class_ID(TCBINTERP_POINT3_CLASS_ID,0) ||
		   cont->ClassID()==Class_ID(TCBINTERP_SCALE_CLASS_ID,0)
		 );
}


BOOL SkeletonExporter::IsBezierControl(Control *cont)
{
  return (
		   cont->ClassID()==Class_ID(HYBRIDINTERP_FLOAT_CLASS_ID,0) ||
		   cont->ClassID()==Class_ID(HYBRIDINTERP_POSITION_CLASS_ID,0) ||
		   cont->ClassID()==Class_ID(HYBRIDINTERP_ROTATION_CLASS_ID,0) ||
		   cont->ClassID()==Class_ID(HYBRIDINTERP_POINT3_CLASS_ID,0) ||
		   cont->ClassID()==Class_ID(HYBRIDINTERP_SCALE_CLASS_ID,0) ||
		   cont->ClassID()==Class_ID(HYBRIDINTERP_COLOR_CLASS_ID,0)
		 );
}


BOOL SkeletonExporter::IsLinearControl(Control *cont)
{
  return (
		   cont->ClassID()==Class_ID(LININTERP_FLOAT_CLASS_ID,0) ||
		   cont->ClassID()==Class_ID(LININTERP_POSITION_CLASS_ID,0) ||
		   cont->ClassID()==Class_ID(LININTERP_ROTATION_CLASS_ID,0) ||
//		   cont->ClassID()==Class_ID(LININTERP_POINT3_CLASS_ID,0) ||
		   cont->ClassID()==Class_ID(LININTERP_SCALE_CLASS_ID,0)
		 );
}


void SkeletonExporter::calc_bezier_Point3_tangents(
					   TimeValue t1, TimeValue t2, Control *c,
		               Point3 *Tan0, Point3 *Tan1)
{
   TimeValue time1, time2, time3, time4;
   Point3 p1, p2, p3, p4;
   Point3 A, B, C, D;
   Interval valid=FOREVER;

   time1=t1;
   time4=t2;
   //time2=t1+(t2-t1)/3;
   //time3=t2-(t2-t1)/3;
   
   time2=t1+GetTicksPerFrame()/3;
   time3=t2-GetTicksPerFrame()/3;

   c->GetValue(time1, &p1, valid);
   c->GetValue(time2, &p2, valid);
   c->GetValue(time3, &p3, valid);
   c->GetValue(time4, &p4, valid);
/*
   A =  (-9/2)*p1 +  (27/2)*p2 + (-27/2)*p3 +  (9/2)*p4;
   B =     (9)*p1 + (-45/2)*p2 +    (18)*p3 + (-9/2)*p4;
   C = (-11/2)*p1 +     (9)*p2 +  (-9/2)*p3 +    (1)*p4;
   D =         p1;
   *Tan0=C;
   *Tan1=3*A+2*B+C;
*/
   A=(p2-p1)*0.33f;
   B=(p4-p3)*0.33f;
   *Tan0=A;
   *Tan1=B;
}

// ###########################################################
// ##################   TRACCE DI Point3   ###################
// ###########################################################

void SkeletonExporter::export_1Key_Point3_track(Control *c, FILE *f)
{
  int keytime=0;
  int numkeys=1;
  Point3 pval;
  unsigned char type;
  Interval valid;
  float s=0;
  
  // Interpolazione TCB
  type=TCB_CONTROLLER;
  fwrite(&type, sizeof(unsigned char), 1, f);
  fwrite(&numkeys, sizeof(int), 1, f);
  fprintf(fTXT, " Type is TCB\n");
  fprintf(fTXT, "Number of keys : %d\n", numkeys);

  c->GetValue(0, &pval, valid);
  fprintf(fTXT, "key settings : t=%f, c=%f, b=%f, et=%f, ef=%f\n",
		      s, s, s, s, s);
  fprintf(fTXT, "timepos : %d,  value %f, %f, %f\n",
	      keytime, pval.x, pval.y, pval.z);

  // key values
  fwrite(&keytime, sizeof(int), 1, f);  // timepos=0
  fwrite(&pval.x, sizeof(float), 1, f);
  fwrite(&pval.y, sizeof(float), 1, f);
  fwrite(&pval.z, sizeof(float), 1, f);

  // key settings
  fwrite(&s, sizeof(float), 1, f);
  fwrite(&s, sizeof(float), 1, f);
  fwrite(&s, sizeof(float), 1, f);
  fwrite(&s, sizeof(float), 1, f);
  fwrite(&s, sizeof(float), 1, f);
}


void SkeletonExporter::export_Point3_track(Control *c, FILE *f)
{
  int numkeys;
  int keytime;
  ITCBPoint3Key kTCB;
  IBezPoint3Key kBEZ, kBEZ2;
  ILinPoint3Key kLIN;
  Point3 T, l, p;
  unsigned char type;
  float f0=0, dt;
  
//  if (!c) return;
//  if (!IsKnownController(c)) return;

  // ci devono essere almeno 1 key
  numkeys = c->NumKeys();
  if (numkeys==NOT_KEYFRAMEABLE || numkeys==0) return;
  
  // Get the keyframe interface
  IKeyControl *ikeys = GetKeyControlInterface(c);

  //  --------------------------------------------------
  // |  Differenziamo secondo il tipo di interpolazione |
  //  --------------------------------------------------


  // Interpolazione TCB
  if (IsTCBControl(c) && ikeys)
  {
	type=TCB_CONTROLLER;
	fwrite(&type, sizeof(unsigned char), 1, f);
	fwrite(&numkeys, sizeof(int), 1, f);

    fprintf(fTXT, " Type is TCB\n");
    fprintf(fTXT, "Number of keys : %d\n", numkeys);
	
    for (int i=0; i<numkeys; i++) 
	{
	  ikeys->GetKey(i, &kTCB);

	  fprintf(fTXT, "key settings : t=%f, c=%f, b=%f, et=%f, ef=%f\n",
		      kTCB.tens, kTCB.cont, kTCB.bias, kTCB.easeIn, kTCB.easeOut);

	  keytime = kTCB.time/GetTicksPerFrame();
      fprintf(fTXT, "timepos : %d,  value %f, %f, %f\n",
		      keytime, kTCB.val.x, kTCB.val.y, kTCB.val.z);

	  // timeline position
	  fwrite(&keytime, sizeof(int), 1, f);
	  // key values
	  fwrite(&kTCB.val.x, sizeof(float), 1, f);
	  fwrite(&kTCB.val.y, sizeof(float), 1, f);
	  fwrite(&kTCB.val.z, sizeof(float), 1, f);
	  // key settings
	  fwrite(&kTCB.tens, sizeof(float), 1, f);
	  fwrite(&kTCB.cont, sizeof(float), 1, f);
	  fwrite(&kTCB.bias, sizeof(float), 1, f);
	  fwrite(&kTCB.easeIn, sizeof(float), 1, f);
	  fwrite(&kTCB.easeOut, sizeof(float), 1, f);
	}
  }
  else
  // Interpolazione BEZIER
  if (IsBezierControl(c) && ikeys)
  {
    type=BEZIER_CONTROLLER;
	fwrite(&type, sizeof(unsigned char), 1, f);
	fwrite(&numkeys, sizeof(int), 1, f);
	fprintf(fTXT, " Type is Bezier\n");
    fprintf(fTXT, "Number of keys : %d\n", numkeys);

    for (int i=0; i<numkeys; i++) 
	{
	  ikeys->GetKey(i, &kBEZ);
	  keytime = kBEZ.time/GetTicksPerFrame();
      fprintf(fTXT, "timepos : %d,  value %f, %f, %f\n", keytime, kBEZ.val.x, kBEZ.val.y, kBEZ.val.z);
	  fwrite(&keytime, sizeof(int), 1, f);
	  fwrite(&kBEZ.val.x, sizeof(float), 1, f);
	  fwrite(&kBEZ.val.y, sizeof(float), 1, f);
	  fwrite(&kBEZ.val.z, sizeof(float), 1, f);

	  // incoming tangent
	  if (i==0)
	  {
         fwrite(&f0, sizeof(float), 3, f);
		 fprintf(fTXT, "inTan: %f, %f, %f\n", 0, 0, 0);
	  }
	  else
	  {
	     p=kBEZ.intan; l=kBEZ.inLength;
		 ikeys->GetKey(i-1, &kBEZ2);
         dt=(kBEZ2.time-kBEZ.time);
	     T.x=p.x*dt;
	     T.y=p.y*dt;
	     T.z=p.z*dt;
	     fprintf(fTXT, "inTan: %f, %f, %f, %f\n", T.x, T.y, T.z, dt);
	     fwrite(&T.x, sizeof(float), 1, f);
	     fwrite(&T.y, sizeof(float), 1, f);
	     fwrite(&T.z, sizeof(float), 1, f);
	  }
	  // outcoming tangent
	  if (i==numkeys-1)
	  {
         fwrite(&f0, sizeof(float), 3, f);
		 fprintf(fTXT, "outTan: %f, %f, %f\n", 0, 0, 0);
	  }
	  else
	  {
	     p=kBEZ.outtan; l=kBEZ.outLength;
		 ikeys->GetKey(i+1, &kBEZ2);
         dt=(kBEZ2.time-kBEZ.time);
	     T.x=p.x*dt;
	     T.y=p.y*dt;
	     T.z=p.z*dt;
	     fprintf(fTXT, "outTan: %f, %f, %f %f\n", T.x, T.y, T.z, dt);
	     fwrite(&T.x, sizeof(float), 1, f);
	     fwrite(&T.y, sizeof(float), 1, f);
	     fwrite(&T.z, sizeof(float), 1, f);
	  }
	}
  }
  else // Interpolazione LINEARE
  if (IsLinearControl(c) && ikeys)
  {
	type=LINEAR_CONTROLLER;
	fwrite(&type, sizeof(unsigned char), 1, f);
	fwrite(&numkeys, sizeof(int), 1, f);
    fprintf(fTXT, " Type is Linear\n");
    fprintf(fTXT, "Number of keys : %d\n", numkeys);
    for (int i=0; i<numkeys; i++) 
	{
	  ikeys->GetKey(i, &kLIN);
	  keytime = kLIN.time/GetTicksPerFrame();
	  fprintf(fTXT, "timepos : %d,  value %f, %f, %f\n",
              keytime, kLIN.val.x, kLIN.val.y, kLIN.val.z);

	  // timeline position
	  fwrite(&keytime, sizeof(int), 1, f);

	  // key values
	  fwrite(&kLIN.val.x, sizeof(float), 1, f);
	  fwrite(&kLIN.val.y, sizeof(float), 1, f);
	  fwrite(&kLIN.val.z, sizeof(float), 1, f);
	}
  }
}



// ###########################################################
// ###################   TRACCE DI Float   ###################
// ###########################################################

void SkeletonExporter::export_1Key_float_track(Control *c, float scale, FILE *f)
{
  int keytime=0;
  int numkeys=1;
  float fval;
  unsigned char type;
  Interval valid;
  float s=0;
  
  // Interpolazione TCB
  type=TCB_CONTROLLER;
  fwrite(&type, sizeof(unsigned char), 1, f);
  fwrite(&numkeys, sizeof(int), 1, f);
  fprintf(fTXT, " Type is TCB\n");
  fprintf(fTXT, "Number of keys : %d\n", numkeys);

  c->GetValue(0, &fval, valid);
  fval*=scale;
  fprintf(fTXT, "key settings : t=%f, c=%f, b=%f, et=%f, ef=%f\n",
		      s, s, s, s, s);
  fprintf(fTXT, "timepos : %d,  value %f\n",
	      keytime, fval);

  // key values
  fwrite(&keytime, sizeof(int), 1, f);  // timepos=0
  fwrite(&fval, sizeof(float), 1, f);

  // key settings
  fwrite(&s, sizeof(float), 1, f);
  fwrite(&s, sizeof(float), 1, f);
  fwrite(&s, sizeof(float), 1, f);
  fwrite(&s, sizeof(float), 1, f);
  fwrite(&s, sizeof(float), 1, f);
}


void SkeletonExporter::export_float_track(Control *c, float scale, FILE *f)
{
  int numkeys;
  int keytime;
  ITCBFloatKey kTCB;
  IBezFloatKey kBEZ, kBEZ2;
  ILinFloatKey kLIN;
  unsigned char type;
  float fval, l , p, T, f0=0, dt;
  
//  if (!c) return;
//  if (!IsKnownController(c)) return;


  // ci devono essere almeno 1 key
  numkeys = c->NumKeys();
  if (numkeys==NOT_KEYFRAMEABLE || numkeys==0) return;

  // Get the keyframe interface
  IKeyControl *ikeys = GetKeyControlInterface(c);

  //  --------------------------------------------------
  // |  Differenziamo secondo il tipo di interpolazione |
  //  --------------------------------------------------


  // Interpolazione TCB  
  if (IsTCBControl(c) && ikeys)
  {
	type=TCB_CONTROLLER;
	fwrite(&type, sizeof(unsigned char), 1, f);
	fwrite(&numkeys, sizeof(int), 1, f);
    fprintf(fTXT, " Type is TCB\n");
    fprintf(fTXT, "Number of keys : %d\n", numkeys);
    for (int i=0; i<numkeys; i++) 
	{
	  ikeys->GetKey(i, &kTCB);
      fval=kTCB.val*scale;
	  
	  fprintf(fTXT, "key settings : t=%f, c=%f, b=%f, et=%f, ef=%f\n",
		      kTCB.tens, kTCB.cont, kTCB.bias, kTCB.easeIn, kTCB.easeOut);

	  keytime = kTCB.time/GetTicksPerFrame();
      fprintf(fTXT, "timepos : %d,  value %f\n",
		      keytime, fval);

	  // timeline position
	  fwrite(&keytime, sizeof(int), 1, f);

	  // key values
	  fwrite(&fval, sizeof(float), 1, f);

	  // key settings
	  fwrite(&kTCB.tens, sizeof(float), 1, f);
	  fwrite(&kTCB.cont, sizeof(float), 1, f);
	  fwrite(&kTCB.bias, sizeof(float), 1, f);
	  fwrite(&kTCB.easeIn, sizeof(float), 1, f);
	  fwrite(&kTCB.easeOut, sizeof(float), 1, f);
	}
  }
  else

  // Interpolazione BEZIER
  if (IsBezierControl(c) && ikeys)
  {
    type=BEZIER_CONTROLLER;
	fwrite(&type, sizeof(unsigned char), 1, f);
	fwrite(&numkeys, sizeof(int), 1, f);
	fprintf(fTXT, " Type is Bezier\n");
    fprintf(fTXT, "Number of keys : %d\n", numkeys);
    for (int i=0; i<numkeys; i++) 
	{
	  ikeys->GetKey(i, &kBEZ);
      fval=kBEZ.val*scale;

	  keytime = kBEZ.time/GetTicksPerFrame();
      fprintf(fTXT, "timepos : %d,  value %f\n", keytime, fval);
	  // timeline position
	  fwrite(&keytime, sizeof(int), 1, f);
	  // key values
	  fwrite(&fval, sizeof(float), 1, f);

	  // incoming tangent
	  if (i==0)
	  {
         fwrite(&f0, sizeof(float), 1, f);
		 fprintf(fTXT, "inTan: %f\n", 0);
	  }
	  else
	  {
	     p=scale*kBEZ.intan; l=kBEZ.inLength;
		 ikeys->GetKey(i-1, &kBEZ2);
         dt=(kBEZ2.time-kBEZ.time);
	     T=p*dt;
	     fprintf(fTXT, "inTan: %f\n", T);
	     fwrite(&T, sizeof(float), 1, f);
	  }
	  // outcoming tangent
	  if (i==numkeys-1)
	  {
         fwrite(&f0, sizeof(float), 1, f);
		 fprintf(fTXT, "outTan: %f\n", 0);
	  }
	  else
	  {
	     p=scale*kBEZ.outtan; l=kBEZ.outLength;
		 ikeys->GetKey(i+1, &kBEZ2);
         dt=(kBEZ2.time-kBEZ.time);
	     T=p*dt;
	     fprintf(fTXT, "outTan: %f\n", T);
	     fwrite(&T, sizeof(float), 1, f);
	  }
	}
  }
  else
  // Interpolazione LINEARE
  if (IsLinearControl(c) && ikeys)
  {
	type=LINEAR_CONTROLLER;
	fwrite(&type, sizeof(unsigned char), 1, f);
	fwrite(&numkeys, sizeof(int), 1, f);
    fprintf(fTXT, " Type is Linear\n");
    fprintf(fTXT, "Number of keys : %d\n", numkeys);
    for (int i=0; i<numkeys; i++) 
	{
	  ikeys->GetKey(i, &kLIN);
      fval=kLIN.val*scale;

	  keytime = kLIN.time/GetTicksPerFrame();
	  fprintf(fTXT, "timepos : %d,  value %f\n",
              keytime, fval);

	  // timeline position
	  fwrite(&keytime, sizeof(int), 1, f);

	  // key values
	  fwrite(&fval, sizeof(float), 1, f);
	}
  }
}


// ###########################################################
// ################   TRACCE DI Rotazione   ##################
// ###########################################################

void SkeletonExporter::export_1Key_Rot_track(Control *c, FILE *f)
{
  int keytime=0;
  int numkeys=1;
  Quat qval;
  unsigned char type;
  Interval valid;
  float s=0, angle;
  Point3 axis;
  
  // Interpolazione TCB
  type=TCB_CONTROLLER;
  fwrite(&type, sizeof(unsigned char), 1, f);
  fwrite(&numkeys, sizeof(int), 1, f);
  fprintf(fTXT, " Type is TCB\n");
  fprintf(fTXT, "Number of keys : %d\n", numkeys);

  c->GetValue(0, &qval, valid);
  AngAxisFromQ(qval, &angle, axis);

  fprintf(fTXT, "key settings : t=%f, c=%f, b=%f, et=%f, ef=%f\n",
		      s, s, s, s, s);
  fprintf(fTXT, "timepos : %d,  value %f, %f, %f,  %f\n",
	      keytime, axis.x, axis.y, axis.z, angle);

  // key values
  fwrite(&keytime, sizeof(int), 1, f);  // timepos=0
  fwrite(&axis.x, sizeof(float), 1, f);
  fwrite(&axis.y, sizeof(float), 1, f);
  fwrite(&axis.z, sizeof(float), 1, f);
  fwrite(&angle, sizeof(float), 1, f);

  // key settings
  fwrite(&s, sizeof(float), 1, f);
  fwrite(&s, sizeof(float), 1, f);
  fwrite(&s, sizeof(float), 1, f);
  fwrite(&s, sizeof(float), 1, f);
  fwrite(&s, sizeof(float), 1, f);
}


void SkeletonExporter::export_Rot_track(Control *c, FILE *f)
{
  int numkeys;
  int keytime;
  ITCBRotKey kTCB;
  IBezQuatKey kBEZ;
  ILinRotKey kLIN;
  unsigned char type;
  float angle;
  Point3 axis;
  
//  if (!c) return;
//  if (!IsKnownController(c)) return;

  // ci devono essere almeno 1 key
  numkeys = c->NumKeys();
  if (numkeys==NOT_KEYFRAMEABLE || numkeys==0) return;

  // Get the keyframe interface
  IKeyControl *ikeys = GetKeyControlInterface(c);

  //  --------------------------------------------------
  // |  Differenziamo secondo il tipo di interpolazione |
  //  --------------------------------------------------


  // Interpolazione TCB
  if (IsTCBControl(c) && ikeys)
  {
	type=TCB_CONTROLLER;
	fwrite(&type, sizeof(unsigned char), 1, f);
	fwrite(&numkeys, sizeof(int), 1, f);
    fprintf(fTXT, " Type is TCB\n");
    fprintf(fTXT, "Number of keys : %d\n", numkeys);
	
    for (int i=0; i<numkeys; i++) 
	{
	  ikeys->GetKey(i, &kTCB);

	  fprintf(fTXT, "key settings : t=%f, c=%f, b=%f, et=%f, ef=%f\n",
		      kTCB.tens, kTCB.cont, kTCB.bias, kTCB.easeIn, kTCB.easeOut);

	  keytime = kTCB.time/GetTicksPerFrame();
      fprintf(fTXT, "timepos : %d,  value %f, %f, %f, %f\n",
		      keytime, kTCB.val.axis.x, kTCB.val.axis.y, kTCB.val.axis.z, kTCB.val.angle);

	  // timeline position
	  fwrite(&keytime, sizeof(int), 1, f);

	  // key values
	  fwrite(&kTCB.val.axis.x, sizeof(float), 1, f);
	  fwrite(&kTCB.val.axis.y, sizeof(float), 1, f);
	  fwrite(&kTCB.val.axis.z, sizeof(float), 1, f);
	  fwrite(&kTCB.val.angle, sizeof(float), 1, f);

	  // key settings
	  fwrite(&kTCB.tens, sizeof(float), 1, f);
	  fwrite(&kTCB.cont, sizeof(float), 1, f);
	  fwrite(&kTCB.bias, sizeof(float), 1, f);
	  fwrite(&kTCB.easeIn, sizeof(float), 1, f);
	  fwrite(&kTCB.easeOut, sizeof(float), 1, f);
	}
  }
  else
  // Interpolazione BEZIER
  if (IsBezierControl(c) && ikeys)
  {
    type=BEZIER_CONTROLLER;
	fwrite(&type, sizeof(unsigned char), 1, f);
	fwrite(&numkeys, sizeof(int), 1, f);
	fprintf(fTXT, " Type is Bezier\n");
    fprintf(fTXT, "Number of keys : %d\n", numkeys);
    for (int i=0; i<numkeys; i++) 
	{
	  ikeys->GetKey(i, &kBEZ);
	  keytime = kBEZ.time/GetTicksPerFrame();

	  AngAxisFromQ(kBEZ.val, &angle, axis);
      fprintf(fTXT, "timepos : %d,  value %f, %f, %f, %f\n",
		      keytime, axis.x, axis.y, axis.z, angle);

	  // timeline position
	  fwrite(&keytime, sizeof(int), 1, f);

	  // key values
	  fwrite(&axis.x, sizeof(float), 1, f);
	  fwrite(&axis.y, sizeof(float), 1, f);
	  fwrite(&axis.z, sizeof(float), 1, f);
	  fwrite(&angle, sizeof(float), 1, f);
	}
  }
  else
  // Interpolazione LINEARE
  if (IsLinearControl(c) && ikeys)
  {
	type=LINEAR_CONTROLLER;
	fwrite(&type, sizeof(unsigned char), 1, f);
	fwrite(&numkeys, sizeof(int), 1, f);
    fprintf(fTXT, " Type is Linear\n");
    fprintf(fTXT, "Number of keys : %d\n", numkeys);
    for (int i=0; i<numkeys; i++) 
	{
	  ikeys->GetKey(i, &kLIN);
	  keytime = kLIN.time/GetTicksPerFrame();
      AngAxisFromQ(kLIN.val, &angle, axis);

	  fprintf(fTXT, "timepos : %d,  value %f, %f, %f\n",
              keytime, axis.x, axis.y, axis.z, angle);

	  // timeline position
	  fwrite(&keytime, sizeof(int), 1, f);

	  // key values
	  fwrite(&axis.x, sizeof(float), 1, f);
	  fwrite(&axis.y, sizeof(float), 1, f);
	  fwrite(&axis.z, sizeof(float), 1, f);
	  fwrite(&angle, sizeof(float), 1, f);
	}
  }
}



// ###########################################################
// ##################   TRACCE DI SCALING  ###################
// ###########################################################

void SkeletonExporter::export_1Key_scale_track(Control *c, FILE *f)
{
  int keytime=0;
  int numkeys=1;
  ScaleValue sval;
  unsigned char type;
  Interval valid;
  float s=0;
  
  // Interpolazione TCB
  type=TCB_CONTROLLER;
  fwrite(&type, sizeof(unsigned char), 1, f);
  fwrite(&numkeys, sizeof(int), 1, f);
  fprintf(fTXT, " Type is TCB\n");
  fprintf(fTXT, "Number of keys : %d\n", numkeys);

  c->GetValue(0, &sval, valid);
  fprintf(fTXT, "key settings : t=%f, c=%f, b=%f, et=%f, ef=%f\n",
		      s, s, s, s, s);
  fprintf(fTXT, "timepos : %d,  value %f, %f, %f\n",
	      keytime, sval.s.x, sval.s.y, sval.s.z);

  // key values
  fwrite(&keytime, sizeof(int), 1, f);  // timepos=0
  fwrite(&sval.s.x, sizeof(float), 1, f);
  fwrite(&sval.s.y, sizeof(float), 1, f);
  fwrite(&sval.s.z, sizeof(float), 1, f);

  // key settings
  fwrite(&s, sizeof(float), 1, f);
  fwrite(&s, sizeof(float), 1, f);
  fwrite(&s, sizeof(float), 1, f);
  fwrite(&s, sizeof(float), 1, f);
  fwrite(&s, sizeof(float), 1, f);
}


void SkeletonExporter::export_scale_track(Control *c, FILE *f)
{
  int numkeys;
  int keytime;
  ITCBScaleKey  kTCB;
  IBezScaleKey  kBEZ, kBEZ2;
  ILinScaleKey  kLIN;
  unsigned char type;
  float dt, f0=0;
  Point3 l, p, T;
  
  if (!c) return;
//  if (!IsKnownController(c)) return;

  // ci devono essere almeno 1 key
  numkeys = c->NumKeys();
  if (numkeys==NOT_KEYFRAMEABLE || numkeys==0) return;

  // Get the keyframe interface
  IKeyControl *ikeys = GetKeyControlInterface(c);

  //  --------------------------------------------------
  // |  Differenziamo secondo il tipo di interpolazione |
  //  --------------------------------------------------


  // Interpolazione TCB
  if (IsTCBControl(c) && ikeys)
  {
	type=TCB_CONTROLLER;
	fwrite(&type, sizeof(unsigned char), 1, f);
	fwrite(&numkeys, sizeof(int), 1, f);
    fprintf(fTXT, " Type is TCB\n");
    fprintf(fTXT, "Number of keys : %d\n", numkeys);
	
    for (int i=0; i<numkeys; i++) 
	{
	  ikeys->GetKey(i, &kTCB);

	  fprintf(fTXT, "key settings : t=%f, c=%f, b=%f, et=%f, ef=%f\n",
		      kTCB.tens, kTCB.cont, kTCB.bias, kTCB.easeIn, kTCB.easeOut);

	  keytime = kTCB.time/GetTicksPerFrame();
      fprintf(fTXT, "timepos : %d,  value %f, %f, %f\n",
		      keytime, kTCB.val.s.x, kTCB.val.s.y, kTCB.val.s.z);

	  // timeline position
	  fwrite(&keytime, sizeof(int), 1, f);

	  // key values
	  fwrite(&kTCB.val.s.x, sizeof(float), 1, f);
	  fwrite(&kTCB.val.s.y, sizeof(float), 1, f);
	  fwrite(&kTCB.val.s.z, sizeof(float), 1, f);

	  // key settings
	  fwrite(&kTCB.tens, sizeof(float), 1, f);
	  fwrite(&kTCB.cont, sizeof(float), 1, f);
	  fwrite(&kTCB.bias, sizeof(float), 1, f);
	  fwrite(&kTCB.easeIn, sizeof(float), 1, f);
	  fwrite(&kTCB.easeOut, sizeof(float), 1, f);
	}
  }
  else

  // Interpolazione BEZIER
  if (IsBezierControl(c) && ikeys)
  {
    type=BEZIER_CONTROLLER;
	fwrite(&type, sizeof(unsigned char), 1, f);
	fwrite(&numkeys, sizeof(int), 1, f);
	fprintf(fTXT, " Type is Bezier\n");
    fprintf(fTXT, "Number of keys : %d\n", numkeys);
    for (int i=0; i<numkeys; i++) 
	{
	  ikeys->GetKey(i, &kBEZ);
	  keytime = kBEZ.time/GetTicksPerFrame();
      fprintf(fTXT, "timepos : %d,  value %f, %f, %f\n",
		      keytime, kBEZ.val.s.x, kBEZ.val.s.y, kBEZ.val.s.z);

	  // timeline position
	  fwrite(&keytime, sizeof(int), 1, f);
	  // key values
	  fwrite(&kBEZ.val.s.x, sizeof(float), 1, f);
	  fwrite(&kBEZ.val.s.y, sizeof(float), 1, f);
	  fwrite(&kBEZ.val.s.z, sizeof(float), 1, f);

	  // incoming tangent
	  if (i==0)
	  {
         fwrite(&f0, sizeof(float), 3, f);
		 fprintf(fTXT, "inTan: %f, %f, %f\n", 0, 0, 0);
	  }
	  else
	  {
	     p=kBEZ.intan; l=kBEZ.inLength;
		 ikeys->GetKey(i-1, &kBEZ2);
         dt=(kBEZ2.time-kBEZ.time);
	     T.x=p.x*dt;
	     T.y=p.y*dt;
	     T.z=p.z*dt;
	     fprintf(fTXT, "inTan: %f, %f, %f, %f\n", T.x, T.y, T.z, dt);
	     fwrite(&T.x, sizeof(float), 1, f);
	     fwrite(&T.y, sizeof(float), 1, f);
	     fwrite(&T.z, sizeof(float), 1, f);
	  }
	  // outcoming tangent
	  if (i==numkeys-1)
	  {
         fwrite(&f0, sizeof(float), 3, f);
		 fprintf(fTXT, "outTan: %f, %f, %f\n", 0, 0, 0);
	  }
	  else
	  {
	     p=kBEZ.outtan; l=kBEZ.outLength;
		 ikeys->GetKey(i+1, &kBEZ2);
         dt=(kBEZ2.time-kBEZ.time);
	     T.x=p.x*dt;
	     T.y=p.y*dt;
	     T.z=p.z*dt;
	     fprintf(fTXT, "outTan: %f, %f, %f %f\n", T.x, T.y, T.z, dt);
	     fwrite(&T.x, sizeof(float), 1, f);
	     fwrite(&T.y, sizeof(float), 1, f);
	     fwrite(&T.z, sizeof(float), 1, f);
	  }
	}
  }
  else
  // Interpolazione LINEARE
  if (IsLinearControl(c) && ikeys)
  {
	type=LINEAR_CONTROLLER;
	fwrite(&type, sizeof(unsigned char), 1, f);
	fwrite(&numkeys, sizeof(int), 1, f);
    fprintf(fTXT, " Type is Linear\n");
    fprintf(fTXT, "Number of keys : %d\n", numkeys);
    for (int i=0; i<numkeys; i++) 
	{
	  ikeys->GetKey(i, &kLIN);
	  keytime = kLIN.time/GetTicksPerFrame();
	  fprintf(fTXT, "timepos : %d,  value %f, %f, %f\n",
              keytime, kLIN.val.s.x, kLIN.val.s.y, kLIN.val.s.z);

	  // timeline position
	  fwrite(&keytime, sizeof(int), 1, f);

	  // key values
	  fwrite(&kLIN.val.s.x, sizeof(float), 1, f);
	  fwrite(&kLIN.val.s.y, sizeof(float), 1, f);
	  fwrite(&kLIN.val.s.z, sizeof(float), 1, f);
	}
  }
}
#include "SceneExport.h"
#include "A3Dfile.h"
#include "bipexp.h"

void SkeletonExporter::export_helper_object(INode *node)
{
  int type;
  Control *c;
  Matrix3 ptm;
  Point3 row;
  INode *padre=node->GetParentNode();
  ObjectState os = node->EvalWorldState(0);

  if (os.obj->ClassID()==Class_ID(DUMMY_CLASS_ID, 0))
  {
	 fprintf(fTXT, "Dummy presente %s\n", node->GetName());
	 type=DUMMY_HELPER;
	 if (makeADD)
	 {
	   fprintf(fADD, "  dummy %c%s%c\n  {\n", '"', node->GetName(), '"');
	   fprintf(fADD, "    texture=%cNONE%c;\n", '"', '"');
       fprintf(fADD, "    scale_x=%c160%c;\n", '"', '"');
       fprintf(fADD, "    scale_y=%c160%c;\n", '"', '"');
	   fprintf(fADD, "  }\n\n");
	 }
  }
  // non sono supportati per ora altri tipi di helper(s)
  else return;


  int sf;
  int sm;
  Mtl *materiale=node->GetMtl();
  if ((padre) && (strcmp(padre->GetName(), "Scene Root")!=0))
  sf=strlen(padre->GetName())+1;
  else sf=0;
  if (materiale) sm=strlen(materiale->GetName())+1;
  else sm=0;

  // tipo_helper + flag padre + nome padre + flag materiale
  // + nome materiale +  world position + pivot
  write_chunk_header(fA3D, HELPER_OBJECT_ID, node->GetName(),
	                 4+4+sf+4+sm+12+12);


  fwrite(&type, sizeof(int), 1, fA3D);
  // scrivo il padre (flag, nome)
  fwrite(&sf, sizeof(int), 1, fA3D);
  if (sf>0) write_string0(fA3D, padre->GetName());
  // scrivo il materiale di base (flag, nome)
  fwrite(&sm, sizeof(int), 1, fA3D);
  if (sm>0) write_string0(fA3D, materiale->GetName());


  Matrix3 mat = node->GetNodeTM(0);
  // posizione nel mondo
  row = mat.GetRow(3);
  fprintf(fTXT, "World position : %f,  %f,  %f\n", row.x, row.y, row.z);
  fwrite(&row.x, sizeof(float), 1, fA3D);
  fwrite(&row.y, sizeof(float), 1, fA3D);
  fwrite(&row.z, sizeof(float), 1, fA3D);

  // punto di pivot
  GetPivotOffset(node, &row);
  fprintf(fTXT, "Pivot : %f,  %f,  %f\n", row.x, row.y, row.z);
  fwrite(&row.x, sizeof(float), 1, fA3D);
  fwrite(&row.y, sizeof(float), 1, fA3D);
  fwrite(&row.z, sizeof(float), 1, fA3D);

 
  //------------------------
  // ESPORTAZIONE KEYFRAMER
  //------------------------
  int size_key;

  // NB: per gli oggetti mesh e quant'altre tipologie di
  // oggetti che possono essere linkati (ovvero dove e'
  // possibile implmenetare gerarchie), ad esempio patch
  // di Bezier, helper, esporto SEMPRE una key di posizione
  // una di rotazione ed una di scaling; se il TM controller
  // e' di un biped esporto le tracce usando la export_bipedtracks
  
  // i DUMMY che hanno dei controller dei biped sono gli effettori
  // finali di un Biped (es: mano, piede)
  c=node->GetTMController();
  if ((c->ClassID() == BIPSLAVE_CONTROL_CLASS_ID) ||
      (c->ClassID() == BIPBODY_CONTROL_CLASS_ID) ||
      (c->ClassID() == FOOTPRINT_CLASS_ID))
  {
	 export_bipedtracks(node);
	 fprintf(fTXT, "\n\n");
	 return;
  }

  // POSITION CONTROLLER
  c=node->GetTMController()->GetPositionController();
  if ((c) && (c->NumKeys()>0))
  {
	 if (IsTCBControl(c)) size_key=36;
	 else
	 if (IsBezierControl(c)) size_key=40;
	 else size_key=16;
	 fprintf(fTXT, "Object position track present.");
     write_chunk_header(fA3D, POSITION_TRACK_ID,
	                    node->GetName(), 1+4+c->NumKeys()*size_key);
     export_Point3_track(c, fA3D);
  }
  // esportiamo comunque una key di posizione TCB
  else
  {
	fprintf(fTXT, "Object position track present. (1 key case)");
    fflush(fTXT);
	size_key=36;
    write_chunk_header(fA3D, POSITION_TRACK_ID,
	                   node->GetName(), 1+4+1*size_key);
    export_1Key_Point3_track(c, fA3D);
  }



  // ROTATION CONTROLLER  
  c=node->GetTMController()->GetRotationController();
  if ((c) && (c->NumKeys()>0))
  {
	 if (IsTCBControl(c)) size_key=40;
	 else size_key=20;
	 fprintf(fTXT, "Object rotation track present.");
     write_chunk_header(fA3D, ROTATION_TRACK_ID,
	                    node->GetName(), 1+4+c->NumKeys()*size_key);
     export_Rot_track(c, fA3D);
  }
  // esportiamo comunque una key di rotazione TCB
  else
  {
	fprintf(fTXT, "Object rotation track present. (1 key case).");
	size_key=40;
    write_chunk_header(fA3D, ROTATION_TRACK_ID,
	                   node->GetName(), 1+4+1*size_key);
    export_1Key_Rot_track(c, fA3D);
  }



  // SCALE CONTROLLER
  c=node->GetTMController()->GetScaleController();
  if ((c) && (c->NumKeys()>0))
  {
	 if (IsTCBControl(c)) size_key=36;
	 else
	 if (IsBezierControl(c)) size_key=40;
	 else size_key=16;
	 fprintf(fTXT, "Object scaling track present.");
     write_chunk_header(fA3D, SCALE_TRACK_ID,
	                    node->GetName(), 1+4+c->NumKeys()*size_key);
     export_scale_track(c, fA3D);
  }
  // esportiamo comunque una key di scaling TCB
  else
  {
	fprintf(fTXT, "Object scaling track present. (1 key case).");
	size_key=36;
    write_chunk_header(fA3D, SCALE_TRACK_ID,
	                   node->GetName(), 1+4+1*size_key);
    export_1Key_scale_track(c, fA3D);
  }

  fprintf(fTXT, "\n\n");
}